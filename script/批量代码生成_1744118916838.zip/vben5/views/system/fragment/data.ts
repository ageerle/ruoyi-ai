import type { FormSchemaGetter } from '#/adapter/form';
import type { VxeGridProps } from '#/adapter/vxe-table';


export const querySchema: FormSchemaGetter = () => [
  {
    component: 'Input',
    fieldName: 'kid',
    label: '知识库ID',
  },
  {
    component: 'Input',
    fieldName: 'docId',
    label: '文档ID',
  },
  {
    component: 'Input',
    fieldName: 'fid',
    label: '知识片段ID',
  },
  {
    component: 'Input',
    fieldName: 'idx',
    label: '片段索引下标',
  },
  {
    component: 'Input',
    fieldName: 'content',
    label: '文档内容',
  },
];

// 需要使用i18n注意这里要改成getter形式 否则切换语言不会刷新
// export const columns: () => VxeGridProps['columns'] = () => [
export const columns: VxeGridProps['columns'] = [
  { type: 'checkbox', width: 60 },
  {
    title: '',
    field: 'id',
  },
  {
    title: '知识库ID',
    field: 'kid',
  },
  {
    title: '文档ID',
    field: 'docId',
  },
  {
    title: '知识片段ID',
    field: 'fid',
  },
  {
    title: '片段索引下标',
    field: 'idx',
  },
  {
    title: '文档内容',
    field: 'content',
  },
  {
    title: '备注',
    field: 'remark',
  },
  {
    field: 'action',
    fixed: 'right',
    slots: { default: 'action' },
    title: '操作',
    width: 180,
  },
];

