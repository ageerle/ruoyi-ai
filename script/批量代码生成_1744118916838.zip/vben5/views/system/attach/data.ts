import type { FormSchemaGetter } from '#/adapter/form';
import type { VxeGridProps } from '#/adapter/vxe-table';


export const querySchema: FormSchemaGetter = () => [
  {
    component: 'Input',
    fieldName: 'kid',
    label: '知识库ID',
  },
  {
    component: 'Input',
    fieldName: 'docId',
    label: '文档ID',
  },
  {
    component: 'Textarea',
    fieldName: 'docName',
    label: '文档名称',
  },
  {
    component: 'Select',
    componentProps: {
    },
    fieldName: 'docType',
    label: '文档类型',
  },
  {
    component: 'Input',
    fieldName: 'content',
    label: '文档内容',
  },
];

// 需要使用i18n注意这里要改成getter形式 否则切换语言不会刷新
// export const columns: () => VxeGridProps['columns'] = () => [
export const columns: VxeGridProps['columns'] = [
  { type: 'checkbox', width: 60 },
  {
    title: '',
    field: 'id',
  },
  {
    title: '知识库ID',
    field: 'kid',
  },
  {
    title: '文档ID',
    field: 'docId',
  },
  {
    title: '文档名称',
    field: 'docName',
  },
  {
    title: '文档类型',
    field: 'docType',
  },
  {
    title: '文档内容',
    field: 'content',
  },
  {
    title: '备注',
    field: 'remark',
  },
  {
    field: 'action',
    fixed: 'right',
    slots: { default: 'action' },
    title: '操作',
    width: 180,
  },
];

