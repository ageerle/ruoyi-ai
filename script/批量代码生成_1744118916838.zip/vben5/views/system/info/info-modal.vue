<!--
使用antd原生Form生成 详细用法参考ant-design-vue Form组件文档
vscode默认配置文件会自动格式化/移除未使用依赖
-->
<script setup lang="ts">
import type { RuleObject } from 'ant-design-vue/es/form';
import { computed, ref } from 'vue';

import { Input, Textarea, Select, RadioGroup, CheckboxGroup, DatePicker, Form, FormItem } from 'ant-design-vue';
import { ImageUpload, FileUpload } from '#/components/upload';
import { Tinymce } from '#/components/tinymce';
import { getPopupContainer } from '@vben/utils';
import { pick } from 'lodash-es';


import { useVbenModal } from '@vben/common-ui';
import { $t } from '@vben/locales';
import { cloneDeep } from '@vben/utils';

import { useVbenForm } from '#/adapter/form';
import { infoAdd, infoInfo, infoUpdate } from '#/api/system/info';
import type { InfoForm } from '#/api/system/info/model';

const emit = defineEmits<{ reload: [] }>();

const isUpdate = ref(false);
const title = computed(() => {
  return isUpdate.value ? $t('pages.common.edit') : $t('pages.common.add');
});

/**
 * 定义默认值 用于reset
 */
const defaultValues: Partial<InfoForm> = {
  id: undefined,
  kid: undefined,
  uid: undefined,
  kname: undefined,
  share: undefined,
  description: undefined,
  knowledgeSeparator: undefined,
  questionSeparator: undefined,
  overlapChar: undefined,
  retrieveLimit: undefined,
  textBlockSize: undefined,
  vector: undefined,
  vectorModel: undefined,
  remark: undefined
}

/**
 * 表单数据ref
 */
const formData = ref(defaultValues);

type AntdFormRules<T> = Partial<Record<keyof T, RuleObject[]>> & {
  [key: string]: RuleObject[];
};
/**
 * 表单校验规则
 */
const formRules = ref<AntdFormRules<InfoForm>>({
    kid: [
      { required: true, message: "知识库ID不能为空" }
    ],
    uid: [
      { required: true, message: "用户ID不能为空" }
    ],
    kname: [
      { required: true, message: "知识库名称不能为空" }
    ],
    share: [
      { required: true, message: "是否公开知识库不能为空" }
    ],
    description: [
      { required: true, message: "描述不能为空" }
    ],
    knowledgeSeparator: [
      { required: true, message: "知识分隔符不能为空" }
    ],
    questionSeparator: [
      { required: true, message: "提问分隔符不能为空" }
    ],
    overlapChar: [
      { required: true, message: "重叠字符数不能为空" }
    ],
    retrieveLimit: [
      { required: true, message: "知识库中检索的条数不能为空" }
    ],
    textBlockSize: [
      { required: true, message: "文本块大小不能为空" }
    ],
    vector: [
      { required: true, message: "向量库不能为空" }
    ],
    vectorModel: [
      { required: true, message: "向量模型不能为空" }
    ],
    remark: [
      { required: true, message: "备注不能为空" }
    ]
});

/**
 * useForm解构出表单方法
 */
const { validate, validateInfos, resetFields } = Form.useForm(
  formData,
  formRules,
);

const [BasicModal, modalApi] = useVbenModal({
  class: 'w-[550px]',
  fullscreenButton: false,
  closeOnClickModal: false,
  onClosed: handleCancel,
  onConfirm: handleConfirm,
  onOpenChange: async (isOpen) => {
    if (!isOpen) {
      return null;
    }
    modalApi.modalLoading(true);

    const { id } = modalApi.getData() as { id?: number | string };
    isUpdate.value = !!id;

    if (isUpdate.value && id) {
      const record = await infoInfo(id);
      // 只赋值存在的字段
      const filterRecord = pick(record, Object.keys(defaultValues));
      formData.value = filterRecord;
    }

    modalApi.modalLoading(false);
  },
});

async function handleConfirm() {
  try {
    modalApi.modalLoading(true);
    await validate();
    // 可能会做数据处理 使用cloneDeep深拷贝
    const data = cloneDeep(formData.value);
    await (isUpdate.value ? infoUpdate(data) : infoAdd(data));
    emit('reload');
    await handleCancel();
  } catch (error) {
    console.error(error);
  } finally {
    modalApi.modalLoading(false);
  }
}

async function handleCancel() {
  modalApi.close();
  formData.value = defaultValues;
  resetFields();
}
</script>

<template>
  <BasicModal :title="title">
    <Form :label-col="{ span: 4 }">
      <FormItem label="知识库ID" v-bind="validateInfos.kid">
        <Input v-model:value="formData.kid" :placeholder="$t('ui.formRules.required')" />
      </FormItem>
      <FormItem label="用户ID" v-bind="validateInfos.uid">
        <Input v-model:value="formData.uid" :placeholder="$t('ui.formRules.required')" />
      </FormItem>
      <FormItem label="知识库名称" v-bind="validateInfos.kname">
        <Input v-model:value="formData.kname" :placeholder="$t('ui.formRules.required')" />
      </FormItem>
      <FormItem label="是否公开知识库" v-bind="validateInfos.share">
        <Input v-model:value="formData.share" :placeholder="$t('ui.formRules.required')" />
      </FormItem>
      <FormItem label="描述" v-bind="validateInfos.description">
        <Textarea 
          v-model:value="formData.description" 
          :placeholder="$t('ui.formRules.required')" 
          :rows="4" 
        />
      </FormItem>
      <FormItem label="知识分隔符" v-bind="validateInfos.knowledgeSeparator">
        <Input v-model:value="formData.knowledgeSeparator" :placeholder="$t('ui.formRules.required')" />
      </FormItem>
      <FormItem label="提问分隔符" v-bind="validateInfos.questionSeparator">
        <Input v-model:value="formData.questionSeparator" :placeholder="$t('ui.formRules.required')" />
      </FormItem>
      <FormItem label="重叠字符数" v-bind="validateInfos.overlapChar">
        <Input v-model:value="formData.overlapChar" :placeholder="$t('ui.formRules.required')" />
      </FormItem>
      <FormItem label="知识库中检索的条数" v-bind="validateInfos.retrieveLimit">
        <Input v-model:value="formData.retrieveLimit" :placeholder="$t('ui.formRules.required')" />
      </FormItem>
      <FormItem label="文本块大小" v-bind="validateInfos.textBlockSize">
        <Input v-model:value="formData.textBlockSize" :placeholder="$t('ui.formRules.required')" />
      </FormItem>
      <FormItem label="向量库" v-bind="validateInfos.vector">
        <Input v-model:value="formData.vector" :placeholder="$t('ui.formRules.required')" />
      </FormItem>
      <FormItem label="向量模型" v-bind="validateInfos.vectorModel">
        <Input v-model:value="formData.vectorModel" :placeholder="$t('ui.formRules.required')" />
      </FormItem>
      <FormItem label="备注" v-bind="validateInfos.remark">
        <Textarea 
          v-model:value="formData.remark" 
          :placeholder="$t('ui.formRules.required')" 
          :rows="4" 
        />
      </FormItem>
    </Form>
  </BasicModal>
</template>

