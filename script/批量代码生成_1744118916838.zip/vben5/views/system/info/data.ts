import type { FormSchemaGetter } from '#/adapter/form';
import type { VxeGridProps } from '#/adapter/vxe-table';


export const querySchema: FormSchemaGetter = () => [
  {
    component: 'Input',
    fieldName: 'kid',
    label: '知识库ID',
  },
  {
    component: 'Input',
    fieldName: 'uid',
    label: '用户ID',
  },
  {
    component: 'Input',
    fieldName: 'kname',
    label: '知识库名称',
  },
  {
    component: 'Input',
    fieldName: 'share',
    label: '是否公开知识库',
  },
  {
    component: 'Textarea',
    fieldName: 'description',
    label: '描述',
  },
  {
    component: 'Input',
    fieldName: 'knowledgeSeparator',
    label: '知识分隔符',
  },
  {
    component: 'Input',
    fieldName: 'questionSeparator',
    label: '提问分隔符',
  },
  {
    component: 'Input',
    fieldName: 'overlapChar',
    label: '重叠字符数',
  },
  {
    component: 'Input',
    fieldName: 'retrieveLimit',
    label: '知识库中检索的条数',
  },
  {
    component: 'Input',
    fieldName: 'textBlockSize',
    label: '文本块大小',
  },
  {
    component: 'Input',
    fieldName: 'vector',
    label: '向量库',
  },
  {
    component: 'Input',
    fieldName: 'vectorModel',
    label: '向量模型',
  },
];

// 需要使用i18n注意这里要改成getter形式 否则切换语言不会刷新
// export const columns: () => VxeGridProps['columns'] = () => [
export const columns: VxeGridProps['columns'] = [
  { type: 'checkbox', width: 60 },
  {
    title: '',
    field: 'id',
  },
  {
    title: '知识库ID',
    field: 'kid',
  },
  {
    title: '用户ID',
    field: 'uid',
  },
  {
    title: '知识库名称',
    field: 'kname',
  },
  {
    title: '是否公开知识库',
    field: 'share',
  },
  {
    title: '描述',
    field: 'description',
  },
  {
    title: '知识分隔符',
    field: 'knowledgeSeparator',
  },
  {
    title: '提问分隔符',
    field: 'questionSeparator',
  },
  {
    title: '重叠字符数',
    field: 'overlapChar',
  },
  {
    title: '知识库中检索的条数',
    field: 'retrieveLimit',
  },
  {
    title: '文本块大小',
    field: 'textBlockSize',
  },
  {
    title: '向量库',
    field: 'vector',
  },
  {
    title: '向量模型',
    field: 'vectorModel',
  },
  {
    title: '备注',
    field: 'remark',
  },
  {
    field: 'action',
    fixed: 'right',
    slots: { default: 'action' },
    title: '操作',
    width: 180,
  },
];

