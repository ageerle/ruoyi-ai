export interface FragmentVO {
  /**
   * 
   */
  id: string | number;

  /**
   * 知识库ID
   */
  kid: string | number;

  /**
   * 文档ID
   */
  docId: string | number;

  /**
   * 知识片段ID
   */
  fid: string | number;

  /**
   * 片段索引下标
   */
  idx: string | number;

  /**
   * 文档内容
   */
  content: string;

  /**
   * 备注
   */
  remark: string;

}

export interface FragmentForm extends BaseEntity {
  /**
   * 
   */
  id?: string | number;

  /**
   * 知识库ID
   */
  kid?: string | number;

  /**
   * 文档ID
   */
  docId?: string | number;

  /**
   * 知识片段ID
   */
  fid?: string | number;

  /**
   * 片段索引下标
   */
  idx?: string | number;

  /**
   * 文档内容
   */
  content?: string;

  /**
   * 备注
   */
  remark?: string;

}

export interface FragmentQuery extends PageQuery {
  /**
   * 知识库ID
   */
  kid?: string | number;

  /**
   * 文档ID
   */
  docId?: string | number;

  /**
   * 知识片段ID
   */
  fid?: string | number;

  /**
   * 片段索引下标
   */
  idx?: string | number;

  /**
   * 文档内容
   */
  content?: string;

}
