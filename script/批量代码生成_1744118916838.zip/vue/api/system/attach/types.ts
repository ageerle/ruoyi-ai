export interface AttachVO {
  /**
   * 
   */
  id: string | number;

  /**
   * 知识库ID
   */
  kid: string | number;

  /**
   * 文档ID
   */
  docId: string | number;

  /**
   * 文档名称
   */
  docName: string;

  /**
   * 文档类型
   */
  docType: string;

  /**
   * 文档内容
   */
  content: string;

  /**
   * 备注
   */
  remark: string;

}

export interface AttachForm extends BaseEntity {
  /**
   * 
   */
  id?: string | number;

  /**
   * 知识库ID
   */
  kid?: string | number;

  /**
   * 文档ID
   */
  docId?: string | number;

  /**
   * 文档名称
   */
  docName?: string;

  /**
   * 文档类型
   */
  docType?: string;

  /**
   * 文档内容
   */
  content?: string;

  /**
   * 备注
   */
  remark?: string;

}

export interface AttachQuery extends PageQuery {
  /**
   * 知识库ID
   */
  kid?: string | number;

  /**
   * 文档ID
   */
  docId?: string | number;

  /**
   * 文档名称
   */
  docName?: string;

  /**
   * 文档类型
   */
  docType?: string;

  /**
   * 文档内容
   */
  content?: string;

}
