import request from '@/utils/request';
import {AxiosPromise} from 'axios';
import {AttachForm, AttachQuery, AttachVO} from '@/api/';

/**
 * 查询知识库附件列表
 * @param query
 * @returns {*}
 */

export const listAttach = (query?: AttachQuery): AxiosPromise<AttachVO[]> => {
  return request({
    url: '/system/attach/list',
    method: 'get',
    params: query
  });
};

/**
 * 查询知识库附件详细
 * @param id
 */
export const getAttach = (id: string | number): AxiosPromise<AttachVO> => {
  return request({
    url: '/system/attach/' + id,
    method: 'get'
  });
};

/**
 * 新增知识库附件
 * @param data
 */
export const addAttach = (data: AttachForm) => {
  return request({
    url: '/system/attach',
    method: 'post',
    data: data
  });
};

/**
 * 修改知识库附件
 * @param data
 */
export const updateAttach = (data: AttachForm) => {
  return request({
    url: '/system/attach',
    method: 'put',
    data: data
  });
};

/**
 * 删除知识库附件
 * @param id
 */
export const delAttach = (id: string | number | Array<string | number>) => {
  return request({
    url: '/system/attach/' + id,
    method: 'delete'
  });
};
