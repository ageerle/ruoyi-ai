import request from '@/utils/request';
import {AxiosPromise} from 'axios';
import {InfoForm, InfoQuery, InfoVO} from '@/api/';

/**
 * 查询知识库列表
 * @param query
 * @returns {*}
 */

export const listInfo = (query?: InfoQuery): AxiosPromise<InfoVO[]> => {
  return request({
    url: '/system/info/list',
    method: 'get',
    params: query
  });
};

/**
 * 查询知识库详细
 * @param id
 */
export const getInfo = (id: string | number): AxiosPromise<InfoVO> => {
  return request({
    url: '/system/info/' + id,
    method: 'get'
  });
};

/**
 * 新增知识库
 * @param data
 */
export const addInfo = (data: InfoForm) => {
  return request({
    url: '/system/info',
    method: 'post',
    data: data
  });
};

/**
 * 修改知识库
 * @param data
 */
export const updateInfo = (data: InfoForm) => {
  return request({
    url: '/system/info',
    method: 'put',
    data: data
  });
};

/**
 * 删除知识库
 * @param id
 */
export const delInfo = (id: string | number | Array<string | number>) => {
  return request({
    url: '/system/info/' + id,
    method: 'delete'
  });
};
