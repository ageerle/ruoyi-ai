<template>
  <div class="p-2">
    <transition :enter-active-class="proxy?.animate.searchAnimate.enter" :leave-active-class="proxy?.animate.searchAnimate.leave">
      <div class="search" v-show="showSearch">
        <el-form :model="queryParams" ref="queryFormRef" :inline="true" label-width="68px">
          <el-form-item label="知识库ID" prop="kid">
            <el-input v-model="queryParams.kid" placeholder="请输入知识库ID" clearable @keyup.enter="handleQuery" />
          </el-form-item>
          <el-form-item label="用户ID" prop="uid">
            <el-input v-model="queryParams.uid" placeholder="请输入用户ID" clearable @keyup.enter="handleQuery" />
          </el-form-item>
          <el-form-item label="知识库名称" prop="kname">
            <el-input v-model="queryParams.kname" placeholder="请输入知识库名称" clearable @keyup.enter="handleQuery" />
          </el-form-item>
          <el-form-item label="是否公开知识库" prop="share">
            <el-input v-model="queryParams.share" placeholder="请输入是否公开知识库" clearable @keyup.enter="handleQuery" />
          </el-form-item>
          <el-form-item label="描述" prop="description">
            <el-input v-model="queryParams.description" placeholder="请输入描述" clearable @keyup.enter="handleQuery" />
          </el-form-item>
          <el-form-item label="知识分隔符" prop="knowledgeSeparator">
            <el-input v-model="queryParams.knowledgeSeparator" placeholder="请输入知识分隔符" clearable @keyup.enter="handleQuery" />
          </el-form-item>
          <el-form-item label="提问分隔符" prop="questionSeparator">
            <el-input v-model="queryParams.questionSeparator" placeholder="请输入提问分隔符" clearable @keyup.enter="handleQuery" />
          </el-form-item>
          <el-form-item label="重叠字符数" prop="overlapChar">
            <el-input v-model="queryParams.overlapChar" placeholder="请输入重叠字符数" clearable @keyup.enter="handleQuery" />
          </el-form-item>
          <el-form-item label="知识库中检索的条数" prop="retrieveLimit">
            <el-input v-model="queryParams.retrieveLimit" placeholder="请输入知识库中检索的条数" clearable @keyup.enter="handleQuery" />
          </el-form-item>
          <el-form-item label="文本块大小" prop="textBlockSize">
            <el-input v-model="queryParams.textBlockSize" placeholder="请输入文本块大小" clearable @keyup.enter="handleQuery" />
          </el-form-item>
          <el-form-item label="向量库" prop="vector">
            <el-input v-model="queryParams.vector" placeholder="请输入向量库" clearable @keyup.enter="handleQuery" />
          </el-form-item>
          <el-form-item label="向量模型" prop="vectorModel">
            <el-input v-model="queryParams.vectorModel" placeholder="请输入向量模型" clearable @keyup.enter="handleQuery" />
          </el-form-item>
          <el-form-item>
            <el-button type="primary" icon="Search" @click="handleQuery">搜索</el-button>
            <el-button icon="Refresh" @click="resetQuery">重置</el-button>
          </el-form-item>
        </el-form>
      </div>
    </transition>

    <el-card shadow="never">
      <template #header>
        <el-row :gutter="10" class="mb8">
          <el-col :span="1.5">
            <el-button type="primary" plain icon="Plus" @click="handleAdd" v-hasPermi="['system:info:add']">新增</el-button>
          </el-col>
          <el-col :span="1.5">
            <el-button type="success" plain icon="Edit" :disabled="single" @click="handleUpdate()" v-hasPermi="['system:info:edit']">修改</el-button>
          </el-col>
          <el-col :span="1.5">
            <el-button type="danger" plain icon="Delete" :disabled="multiple" @click="handleDelete()" v-hasPermi="['system:info:remove']">删除</el-button>
          </el-col>
          <el-col :span="1.5">
            <el-button type="warning" plain icon="Download" @click="handleExport" v-hasPermi="['system:info:export']">导出</el-button>
          </el-col>
          <right-toolbar v-model:showSearch="showSearch" @queryTable="getList"></right-toolbar>
        </el-row>
      </template>

      <el-table v-loading="loading" :data="infoList" @selection-change="handleSelectionChange">
        <el-table-column type="selection" width="55" align="center" />
        <el-table-column label="" align="center" prop="id" v-if="true" />
        <el-table-column label="知识库ID" align="center" prop="kid" />
        <el-table-column label="用户ID" align="center" prop="uid" />
        <el-table-column label="知识库名称" align="center" prop="kname" />
        <el-table-column label="是否公开知识库" align="center" prop="share" />
        <el-table-column label="描述" align="center" prop="description" />
        <el-table-column label="知识分隔符" align="center" prop="knowledgeSeparator" />
        <el-table-column label="提问分隔符" align="center" prop="questionSeparator" />
        <el-table-column label="重叠字符数" align="center" prop="overlapChar" />
        <el-table-column label="知识库中检索的条数" align="center" prop="retrieveLimit" />
        <el-table-column label="文本块大小" align="center" prop="textBlockSize" />
        <el-table-column label="向量库" align="center" prop="vector" />
        <el-table-column label="向量模型" align="center" prop="vectorModel" />
        <el-table-column label="备注" align="center" prop="remark" />
        <el-table-column label="操作" align="center" class-name="small-padding fixed-width">
          <template #default="scope">
            <el-tooltip content="修改" placement="top">
              <el-button link type="primary" icon="Edit" @click="handleUpdate(scope.row)" v-hasPermi="['system:info:edit']"></el-button>
            </el-tooltip>
            <el-tooltip content="删除" placement="top">
              <el-button link type="primary" icon="Delete" @click="handleDelete(scope.row)" v-hasPermi="['system:info:remove']"></el-button>
            </el-tooltip>
          </template>
        </el-table-column>
      </el-table>

      <pagination
          v-show="total>0"
          :total="total"
          v-model:page="queryParams.pageNum"
          v-model:limit="queryParams.pageSize"
          @pagination="getList"
      />
    </el-card>
    <!-- 添加或修改知识库对话框 -->
    <el-dialog :title="dialog.title" v-model="dialog.visible" width="500px" append-to-body>
      <el-form ref="infoFormRef" :model="form" :rules="rules" label-width="80px">
        <el-form-item label="知识库ID" prop="kid">
          <el-input v-model="form.kid" placeholder="请输入知识库ID" />
        </el-form-item>
        <el-form-item label="用户ID" prop="uid">
          <el-input v-model="form.uid" placeholder="请输入用户ID" />
        </el-form-item>
        <el-form-item label="知识库名称" prop="kname">
          <el-input v-model="form.kname" placeholder="请输入知识库名称" />
        </el-form-item>
        <el-form-item label="是否公开知识库" prop="share">
          <el-input v-model="form.share" placeholder="请输入是否公开知识库" />
        </el-form-item>
        <el-form-item label="描述" prop="description">
            <el-input v-model="form.description" type="textarea" placeholder="请输入内容" />
        </el-form-item>
        <el-form-item label="知识分隔符" prop="knowledgeSeparator">
          <el-input v-model="form.knowledgeSeparator" placeholder="请输入知识分隔符" />
        </el-form-item>
        <el-form-item label="提问分隔符" prop="questionSeparator">
          <el-input v-model="form.questionSeparator" placeholder="请输入提问分隔符" />
        </el-form-item>
        <el-form-item label="重叠字符数" prop="overlapChar">
          <el-input v-model="form.overlapChar" placeholder="请输入重叠字符数" />
        </el-form-item>
        <el-form-item label="知识库中检索的条数" prop="retrieveLimit">
          <el-input v-model="form.retrieveLimit" placeholder="请输入知识库中检索的条数" />
        </el-form-item>
        <el-form-item label="文本块大小" prop="textBlockSize">
          <el-input v-model="form.textBlockSize" placeholder="请输入文本块大小" />
        </el-form-item>
        <el-form-item label="向量库" prop="vector">
          <el-input v-model="form.vector" placeholder="请输入向量库" />
        </el-form-item>
        <el-form-item label="向量模型" prop="vectorModel">
          <el-input v-model="form.vectorModel" placeholder="请输入向量模型" />
        </el-form-item>
        <el-form-item label="备注" prop="remark">
            <el-input v-model="form.remark" type="textarea" placeholder="请输入内容" />
        </el-form-item>
      </el-form>
      <template #footer>
        <div class="dialog-footer">
          <el-button :loading="buttonLoading" type="primary" @click="submitForm">确 定</el-button>
          <el-button @click="cancel">取 消</el-button>
        </div>
      </template>
    </el-dialog>
  </div>
</template>

<script setup name="Info" lang="ts">
    import {
        addInfo,
            InfoForm,
        getInfo,
        listInfo,
            InfoQuery,
        updateInfo,
            InfoVO
    } from '@/api/';
    import {ComponentInternalInstance} from 'vue';
    import {ElForm} from 'element-plus';

    const { proxy } = getCurrentInstance() as ComponentInternalInstance;

const infoList = ref<InfoVO[]>([]);
const buttonLoading = ref(false);
const loading = ref(true);
const showSearch = ref(true);
const ids = ref<Array<string | number>>([]);
const single = ref(true);
const multiple = ref(true);
const total = ref(0);

const queryFormRef = ref(ElForm);
const infoFormRef = ref(ElForm);

const dialog = reactive<DialogOption>({
  visible: false,
  title: ''
});

const initFormData: InfoForm = {
  id: undefined,
  kid: undefined,
  uid: undefined,
  kname: undefined,
  share: undefined,
  description: undefined,
  knowledgeSeparator: undefined,
  questionSeparator: undefined,
  overlapChar: undefined,
  retrieveLimit: undefined,
  textBlockSize: undefined,
  vector: undefined,
  vectorModel: undefined,
  remark: undefined
}
const data = reactive<PageData<InfoForm, InfoQuery>>({
  form: {...initFormData},
  queryParams: {
    pageNum: 1,
    pageSize: 10,
    kid: undefined,
    uid: undefined,
    kname: undefined,
    share: undefined,
    description: undefined,
    knowledgeSeparator: undefined,
    questionSeparator: undefined,
    overlapChar: undefined,
    retrieveLimit: undefined,
    textBlockSize: undefined,
    vector: undefined,
    vectorModel: undefined,
  },
  rules: {
    id: [
      { required: true, message: "不能为空", trigger: "blur" }
    ],
    kid: [
      { required: true, message: "知识库ID不能为空", trigger: "blur" }
    ],
    uid: [
      { required: true, message: "用户ID不能为空", trigger: "blur" }
    ],
    kname: [
      { required: true, message: "知识库名称不能为空", trigger: "blur" }
    ],
    share: [
      { required: true, message: "是否公开知识库不能为空", trigger: "blur" }
    ],
    description: [
      { required: true, message: "描述不能为空", trigger: "blur" }
    ],
    knowledgeSeparator: [
      { required: true, message: "知识分隔符不能为空", trigger: "blur" }
    ],
    questionSeparator: [
      { required: true, message: "提问分隔符不能为空", trigger: "blur" }
    ],
    overlapChar: [
      { required: true, message: "重叠字符数不能为空", trigger: "blur" }
    ],
    retrieveLimit: [
      { required: true, message: "知识库中检索的条数不能为空", trigger: "blur" }
    ],
    textBlockSize: [
      { required: true, message: "文本块大小不能为空", trigger: "blur" }
    ],
    vector: [
      { required: true, message: "向量库不能为空", trigger: "blur" }
    ],
    vectorModel: [
      { required: true, message: "向量模型不能为空", trigger: "blur" }
    ],
    remark: [
      { required: true, message: "备注不能为空", trigger: "blur" }
    ]
  }
});

const { queryParams, form, rules } = toRefs(data);

/** 查询知识库列表 */
const getList = async () => {
  loading.value = true;
  const res = await listInfo(queryParams.value);
  infoList.value = res.rows;
  total.value = res.total;
  loading.value = false;
}

/** 取消按钮 */
const cancel = () => {
  reset();
  dialog.visible = false;
}

/** 表单重置 */
const reset = () => {
  form.value = {...initFormData};
  infoFormRef.value.resetFields();
}

/** 搜索按钮操作 */
const handleQuery = () => {
  queryParams.value.pageNum = 1;
  getList();
}

/** 重置按钮操作 */
const resetQuery = () => {
  queryFormRef.value.resetFields();
  handleQuery();
}

/** 多选框选中数据 */
const handleSelectionChange = (selection: InfoVO[]) => {
  ids.value = selection.map(item => item.id);
  single.value = selection.length != 1;
  multiple.value = !selection.length;
}

/** 新增按钮操作 */
const handleAdd = () => {
  dialog.visible = true;
  dialog.title = "添加知识库";
  nextTick(() => {
    reset();
  });
}

/** 修改按钮操作 */
const handleUpdate = (row?: InfoVO) => {
  loading.value = true
  dialog.visible = true;
  dialog.title = "修改知识库";
  nextTick(async () => {
    reset();
    const _id = row?.id || ids.value[0]
    const res = await getInfo(_id);
    loading.value = false;
    Object.assign(form.value, res.data);
  });
}

/** 提交按钮 */
const submitForm = () => {
  infoFormRef.value.validate(async (valid: boolean) => {
    if (valid) {
      buttonLoading.value = true;
      if (form.value.id) {
        await updateInfo(form.value).finally(() =>  buttonLoading.value = false);
      } else {
        await addInfo(form.value).finally(() =>  buttonLoading.value = false);
      }
      proxy?.$modal.msgSuccess("修改成功");
      dialog.visible = false;
      await getList();
    }
  });
}

/** 删除按钮操作 */
const handleDelete = async (row?: InfoVO) => {
  const _ids = row?.id || ids.value;
  await proxy?.$modal.confirm('是否确认删除知识库编号为"' + _ids + '"的数据项？').finally(() => loading.value = false);
  await delInfo(_ids);
  proxy?.$modal.msgSuccess("删除成功");
  await getList();
}

/** 导出按钮操作 */
const handleExport = () => {
  proxy?.download('system/info/export', {
    ...queryParams.value
  }, `info_${new Date().getTime()}.xlsx`)
}

onMounted(() => {
  getList();
});
</script>
