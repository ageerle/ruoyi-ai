-- 菜单 SQL
insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(1909599259241054210, '知识库', '3', '1', 'info', 'system/info/index', 1, 0, 'C', '0', '0', 'system:info:list', '#', 103, 1, sysdate(), null, null, '知识库菜单');

-- 按钮 SQL
insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(1909599259241054211, '知识库查询', 1909599259241054210, '1',  '#', '', 1, 0, 'F', '0', '0', 'system:info:query',        '#', 103, 1, sysdate(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(1909599259241054212, '知识库新增', 1909599259241054210, '2',  '#', '', 1, 0, 'F', '0', '0', 'system:info:add',          '#', 103, 1, sysdate(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(1909599259241054213, '知识库修改', 1909599259241054210, '3',  '#', '', 1, 0, 'F', '0', '0', 'system:info:edit',         '#', 103, 1, sysdate(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(1909599259241054214, '知识库删除', 1909599259241054210, '4',  '#', '', 1, 0, 'F', '0', '0', 'system:info:remove',       '#', 103, 1, sysdate(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(1909599259241054215, '知识库导出', 1909599259241054210, '5',  '#', '', 1, 0, 'F', '0', '0', 'system:info:export',       '#', 103, 1, sysdate(), null, null, '');
