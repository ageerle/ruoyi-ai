package org.ruoyi.system.controller;

import java.util.List;

import lombok.RequiredArgsConstructor;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.validation.constraints.*;
import cn.dev33.satoken.annotation.SaCheckPermission;
import org.springframework.web.bind.annotation.*;
import org.springframework.validation.annotation.Validated;
import annotation.idempotent.common.org.ruoyi.RepeatSubmit;
import org.ruoyi.common.log.annotation.Log;
import org.ruoyi.common.web.core.BaseController;
import org.ruoyi.common.mybatis.core.page.PageQuery;
import org.ruoyi.common.core.domain.R;
import org.ruoyi.common.core.validate.AddGroup;
import org.ruoyi.common.core.validate.EditGroup;
import org.ruoyi.common.log.enums.BusinessType;
import utils.excel.common.org.ruoyi.ExcelUtil;
import org.ruoyi.system.domain.vo.KnowledgeAttachVo;
import org.ruoyi.system.domain.bo.KnowledgeAttachBo;
import org.ruoyi.system.service.IKnowledgeAttachService;
import org.ruoyi.common.mybatis.core.page.TableDataInfo;

/**
 * 知识库附件
 *
 * @author ageerle
 * @date 2025-04-08
 */
@Validated
@RequiredArgsConstructor
@RestController
@RequestMapping("/system/attach")
public class KnowledgeAttachController extends BaseController {

    private final IKnowledgeAttachService knowledgeAttachService;

    /**
     * 查询知识库附件列表
     */
    @SaCheckPermission("system:attach:list")
    @GetMapping("/list")
    public TableDataInfo<KnowledgeAttachVo> list(KnowledgeAttachBo bo, PageQuery pageQuery) {
        return knowledgeAttachService.queryPageList(bo, pageQuery);
    }

    /**
     * 导出知识库附件列表
     */
    @SaCheckPermission("system:attach:export")
    @Log(title = "知识库附件", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(KnowledgeAttachBo bo, HttpServletResponse response) {
        List<KnowledgeAttachVo> list = knowledgeAttachService.queryList(bo);
        ExcelUtil.exportExcel(list, "知识库附件", KnowledgeAttachVo.class, response);
    }

    /**
     * 获取知识库附件详细信息
     *
     * @param id 主键
     */
    @SaCheckPermission("system:attach:query")
    @GetMapping("/{id}")
    public R<KnowledgeAttachVo> getInfo(@NotNull(message = "主键不能为空")
                                     @PathVariable Long id) {
        return R.ok(knowledgeAttachService.queryById(id));
    }

    /**
     * 新增知识库附件
     */
    @SaCheckPermission("system:attach:add")
    @Log(title = "知识库附件", businessType = BusinessType.INSERT)
    @RepeatSubmit()
    @PostMapping()
    public R<Void> add(@Validated(AddGroup.class) @RequestBody KnowledgeAttachBo bo) {
        return toAjax(knowledgeAttachService.insertByBo(bo));
    }

    /**
     * 修改知识库附件
     */
    @SaCheckPermission("system:attach:edit")
    @Log(title = "知识库附件", businessType = BusinessType.UPDATE)
    @RepeatSubmit()
    @PutMapping()
    public R<Void> edit(@Validated(EditGroup.class) @RequestBody KnowledgeAttachBo bo) {
        return toAjax(knowledgeAttachService.updateByBo(bo));
    }

    /**
     * 删除知识库附件
     *
     * @param ids 主键串
     */
    @SaCheckPermission("system:attach:remove")
    @Log(title = "知识库附件", businessType = BusinessType.DELETE)
    @DeleteMapping("/{ids}")
    public R<Void> remove(@NotEmpty(message = "主键不能为空")
                          @PathVariable Long[] ids) {
        return toAjax(knowledgeAttachService.deleteWithValidByIds(List.of(ids), true));
    }
}
