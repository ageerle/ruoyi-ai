package org.ruoyi.system.mapper;

import org.ruoyi.system.domain.KnowledgeFragment;
import org.ruoyi.system.domain.vo.KnowledgeFragmentVo;
import org.ruoyi.common.mybatis.core.mapper.BaseMapperPlus;

/**
 * 知识片段Mapper接口
 *
 * @author ageerle
 * @date 2025-04-08
 */
public interface KnowledgeFragmentMapper extends BaseMapperPlus<KnowledgeFragment, KnowledgeFragmentVo> {

}
