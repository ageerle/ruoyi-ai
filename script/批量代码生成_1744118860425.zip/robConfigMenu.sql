-- 菜单 SQL
insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(1909599022141243394, '聊天机器人配置', '3', '1', 'robConfig', 'system/robConfig/index', 1, 0, 'C', '0', '0', 'system:robConfig:list', '#', 103, 1, sysdate(), null, null, '聊天机器人配置菜单');

-- 按钮 SQL
insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(1909599022141243395, '聊天机器人配置查询', 1909599022141243394, '1',  '#', '', 1, 0, 'F', '0', '0', 'system:robConfig:query',        '#', 103, 1, sysdate(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(1909599022141243396, '聊天机器人配置新增', 1909599022141243394, '2',  '#', '', 1, 0, 'F', '0', '0', 'system:robConfig:add',          '#', 103, 1, sysdate(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(1909599022141243397, '聊天机器人配置修改', 1909599022141243394, '3',  '#', '', 1, 0, 'F', '0', '0', 'system:robConfig:edit',         '#', 103, 1, sysdate(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(1909599022141243398, '聊天机器人配置删除', 1909599022141243394, '4',  '#', '', 1, 0, 'F', '0', '0', 'system:robConfig:remove',       '#', 103, 1, sysdate(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(1909599022141243399, '聊天机器人配置导出', 1909599022141243394, '5',  '#', '', 1, 0, 'F', '0', '0', 'system:robConfig:export',       '#', 103, 1, sysdate(), null, null, '');
