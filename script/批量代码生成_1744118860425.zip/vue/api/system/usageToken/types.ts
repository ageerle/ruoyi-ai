export interface UsageTokenVO {
  /**
   * 主键
   */
  id: string | number;

  /**
   * 用户
   */
  userId: string | number;

  /**
   * 待结算token
   */
  token: number;

  /**
   * 模型名称
   */
  modelName: string;

  /**
   * 累计使用token
   */
  totalToken: string;

}

export interface UsageTokenForm extends BaseEntity {
  /**
   * 主键
   */
  id?: string | number;

  /**
   * 用户
   */
  userId?: string | number;

  /**
   * 待结算token
   */
  token?: number;

  /**
   * 模型名称
   */
  modelName?: string;

  /**
   * 累计使用token
   */
  totalToken?: string;

}

export interface UsageTokenQuery extends PageQuery {
  /**
   * 用户
   */
  userId?: string | number;

  /**
   * 待结算token
   */
  token?: number;

  /**
   * 模型名称
   */
  modelName?: string;

  /**
   * 累计使用token
   */
  totalToken?: string;

}
