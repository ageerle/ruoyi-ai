import request from '@/utils/request';
import {AxiosPromise} from 'axios';
import {UsageTokenForm, UsageTokenQuery, UsageTokenVO} from '@/api/';

/**
 * 查询用户token使用详情列表
 * @param query
 * @returns {*}
 */

export const listUsageToken = (query?: UsageTokenQuery): AxiosPromise<UsageTokenVO[]> => {
  return request({
    url: '/system/usageToken/list',
    method: 'get',
    params: query
  });
};

/**
 * 查询用户token使用详情详细
 * @param id
 */
export const getUsageToken = (id: string | number): AxiosPromise<UsageTokenVO> => {
  return request({
    url: '/system/usageToken/' + id,
    method: 'get'
  });
};

/**
 * 新增用户token使用详情
 * @param data
 */
export const addUsageToken = (data: UsageTokenForm) => {
  return request({
    url: '/system/usageToken',
    method: 'post',
    data: data
  });
};

/**
 * 修改用户token使用详情
 * @param data
 */
export const updateUsageToken = (data: UsageTokenForm) => {
  return request({
    url: '/system/usageToken',
    method: 'put',
    data: data
  });
};

/**
 * 删除用户token使用详情
 * @param id
 */
export const delUsageToken = (id: string | number | Array<string | number>) => {
  return request({
    url: '/system/usageToken/' + id,
    method: 'delete'
  });
};
