import request from '@/utils/request';
import {AxiosPromise} from 'axios';
import {RobConfigForm, RobConfigQuery, RobConfigVO} from '@/api/';

/**
 * 查询聊天机器人配置列表
 * @param query
 * @returns {*}
 */

export const listRobConfig = (query?: RobConfigQuery): AxiosPromise<RobConfigVO[]> => {
  return request({
    url: '/system/robConfig/list',
    method: 'get',
    params: query
  });
};

/**
 * 查询聊天机器人配置详细
 * @param id
 */
export const getRobConfig = (id: string | number): AxiosPromise<RobConfigVO> => {
  return request({
    url: '/system/robConfig/' + id,
    method: 'get'
  });
};

/**
 * 新增聊天机器人配置
 * @param data
 */
export const addRobConfig = (data: RobConfigForm) => {
  return request({
    url: '/system/robConfig',
    method: 'post',
    data: data
  });
};

/**
 * 修改聊天机器人配置
 * @param data
 */
export const updateRobConfig = (data: RobConfigForm) => {
  return request({
    url: '/system/robConfig',
    method: 'put',
    data: data
  });
};

/**
 * 删除聊天机器人配置
 * @param id
 */
export const delRobConfig = (id: string | number | Array<string | number>) => {
  return request({
    url: '/system/robConfig/' + id,
    method: 'delete'
  });
};
