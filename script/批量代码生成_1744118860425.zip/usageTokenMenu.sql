-- 菜单 SQL
insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(1909599022728445953, '用户token使用详情', '3', '1', 'usageToken', 'system/usageToken/index', 1, 0, 'C', '0', '0', 'system:usageToken:list', '#', 103, 1, sysdate(), null, null, '用户token使用详情菜单');

-- 按钮 SQL
insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(1909599022728445954, '用户token使用详情查询', 1909599022728445953, '1',  '#', '', 1, 0, 'F', '0', '0', 'system:usageToken:query',        '#', 103, 1, sysdate(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(1909599022728445955, '用户token使用详情新增', 1909599022728445953, '2',  '#', '', 1, 0, 'F', '0', '0', 'system:usageToken:add',          '#', 103, 1, sysdate(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(1909599022728445956, '用户token使用详情修改', 1909599022728445953, '3',  '#', '', 1, 0, 'F', '0', '0', 'system:usageToken:edit',         '#', 103, 1, sysdate(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(1909599022728445957, '用户token使用详情删除', 1909599022728445953, '4',  '#', '', 1, 0, 'F', '0', '0', 'system:usageToken:remove',       '#', 103, 1, sysdate(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(1909599022728445958, '用户token使用详情导出', 1909599022728445953, '5',  '#', '', 1, 0, 'F', '0', '0', 'system:usageToken:export',       '#', 103, 1, sysdate(), null, null, '');
