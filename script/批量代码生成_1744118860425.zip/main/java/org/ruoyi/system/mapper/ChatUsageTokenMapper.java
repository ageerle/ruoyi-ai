package org.ruoyi.system.mapper;

import org.ruoyi.system.domain.ChatUsageToken;
import org.ruoyi.system.domain.vo.ChatUsageTokenVo;
import org.ruoyi.common.mybatis.core.mapper.BaseMapperPlus;

/**
 * 用户token使用详情Mapper接口
 *
 * @author ageerle
 * @date 2025-04-08
 */
public interface ChatUsageTokenMapper extends BaseMapperPlus<ChatUsageToken, ChatUsageTokenVo> {

}
