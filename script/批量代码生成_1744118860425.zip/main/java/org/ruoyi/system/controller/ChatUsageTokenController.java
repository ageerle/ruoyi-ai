package org.ruoyi.system.controller;

import java.util.List;

import lombok.RequiredArgsConstructor;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.validation.constraints.*;
import cn.dev33.satoken.annotation.SaCheckPermission;
import org.springframework.web.bind.annotation.*;
import org.springframework.validation.annotation.Validated;
import annotation.idempotent.common.org.ruoyi.RepeatSubmit;
import org.ruoyi.common.log.annotation.Log;
import org.ruoyi.common.web.core.BaseController;
import org.ruoyi.common.mybatis.core.page.PageQuery;
import org.ruoyi.common.core.domain.R;
import org.ruoyi.common.core.validate.AddGroup;
import org.ruoyi.common.core.validate.EditGroup;
import org.ruoyi.common.log.enums.BusinessType;
import utils.excel.common.org.ruoyi.ExcelUtil;
import org.ruoyi.system.domain.vo.ChatUsageTokenVo;
import org.ruoyi.system.domain.bo.ChatUsageTokenBo;
import org.ruoyi.system.service.IChatUsageTokenService;
import org.ruoyi.common.mybatis.core.page.TableDataInfo;

/**
 * 用户token使用详情
 *
 * @author ageerle
 * @date 2025-04-08
 */
@Validated
@RequiredArgsConstructor
@RestController
@RequestMapping("/system/usageToken")
public class ChatUsageTokenController extends BaseController {

    private final IChatUsageTokenService chatUsageTokenService;

    /**
     * 查询用户token使用详情列表
     */
    @SaCheckPermission("system:usageToken:list")
    @GetMapping("/list")
    public TableDataInfo<ChatUsageTokenVo> list(ChatUsageTokenBo bo, PageQuery pageQuery) {
        return chatUsageTokenService.queryPageList(bo, pageQuery);
    }

    /**
     * 导出用户token使用详情列表
     */
    @SaCheckPermission("system:usageToken:export")
    @Log(title = "用户token使用详情", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(ChatUsageTokenBo bo, HttpServletResponse response) {
        List<ChatUsageTokenVo> list = chatUsageTokenService.queryList(bo);
        ExcelUtil.exportExcel(list, "用户token使用详情", ChatUsageTokenVo.class, response);
    }

    /**
     * 获取用户token使用详情详细信息
     *
     * @param id 主键
     */
    @SaCheckPermission("system:usageToken:query")
    @GetMapping("/{id}")
    public R<ChatUsageTokenVo> getInfo(@NotNull(message = "主键不能为空")
                                     @PathVariable Long id) {
        return R.ok(chatUsageTokenService.queryById(id));
    }

    /**
     * 新增用户token使用详情
     */
    @SaCheckPermission("system:usageToken:add")
    @Log(title = "用户token使用详情", businessType = BusinessType.INSERT)
    @RepeatSubmit()
    @PostMapping()
    public R<Void> add(@Validated(AddGroup.class) @RequestBody ChatUsageTokenBo bo) {
        return toAjax(chatUsageTokenService.insertByBo(bo));
    }

    /**
     * 修改用户token使用详情
     */
    @SaCheckPermission("system:usageToken:edit")
    @Log(title = "用户token使用详情", businessType = BusinessType.UPDATE)
    @RepeatSubmit()
    @PutMapping()
    public R<Void> edit(@Validated(EditGroup.class) @RequestBody ChatUsageTokenBo bo) {
        return toAjax(chatUsageTokenService.updateByBo(bo));
    }

    /**
     * 删除用户token使用详情
     *
     * @param ids 主键串
     */
    @SaCheckPermission("system:usageToken:remove")
    @Log(title = "用户token使用详情", businessType = BusinessType.DELETE)
    @DeleteMapping("/{ids}")
    public R<Void> remove(@NotEmpty(message = "主键不能为空")
                          @PathVariable Long[] ids) {
        return toAjax(chatUsageTokenService.deleteWithValidByIds(List.of(ids), true));
    }
}
