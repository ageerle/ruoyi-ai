package org.ruoyi.system.controller;

import java.util.List;

import lombok.RequiredArgsConstructor;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.validation.constraints.*;
import cn.dev33.satoken.annotation.SaCheckPermission;
import org.springframework.web.bind.annotation.*;
import org.springframework.validation.annotation.Validated;
import annotation.idempotent.common.org.ruoyi.RepeatSubmit;
import org.ruoyi.common.log.annotation.Log;
import org.ruoyi.common.web.core.BaseController;
import org.ruoyi.common.mybatis.core.page.PageQuery;
import org.ruoyi.common.core.domain.R;
import org.ruoyi.common.core.validate.AddGroup;
import org.ruoyi.common.core.validate.EditGroup;
import org.ruoyi.common.log.enums.BusinessType;
import utils.excel.common.org.ruoyi.ExcelUtil;
import org.ruoyi.system.domain.vo.ChatRobConfigVo;
import org.ruoyi.system.domain.bo.ChatRobConfigBo;
import org.ruoyi.system.service.IChatRobConfigService;
import org.ruoyi.common.mybatis.core.page.TableDataInfo;

/**
 * 聊天机器人配置
 *
 * @author ageerle
 * @date 2025-04-08
 */
@Validated
@RequiredArgsConstructor
@RestController
@RequestMapping("/system/robConfig")
public class ChatRobConfigController extends BaseController {

    private final IChatRobConfigService chatRobConfigService;

    /**
     * 查询聊天机器人配置列表
     */
    @SaCheckPermission("system:robConfig:list")
    @GetMapping("/list")
    public TableDataInfo<ChatRobConfigVo> list(ChatRobConfigBo bo, PageQuery pageQuery) {
        return chatRobConfigService.queryPageList(bo, pageQuery);
    }

    /**
     * 导出聊天机器人配置列表
     */
    @SaCheckPermission("system:robConfig:export")
    @Log(title = "聊天机器人配置", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(ChatRobConfigBo bo, HttpServletResponse response) {
        List<ChatRobConfigVo> list = chatRobConfigService.queryList(bo);
        ExcelUtil.exportExcel(list, "聊天机器人配置", ChatRobConfigVo.class, response);
    }

    /**
     * 获取聊天机器人配置详细信息
     *
     * @param id 主键
     */
    @SaCheckPermission("system:robConfig:query")
    @GetMapping("/{id}")
    public R<ChatRobConfigVo> getInfo(@NotNull(message = "主键不能为空")
                                     @PathVariable Long id) {
        return R.ok(chatRobConfigService.queryById(id));
    }

    /**
     * 新增聊天机器人配置
     */
    @SaCheckPermission("system:robConfig:add")
    @Log(title = "聊天机器人配置", businessType = BusinessType.INSERT)
    @RepeatSubmit()
    @PostMapping()
    public R<Void> add(@Validated(AddGroup.class) @RequestBody ChatRobConfigBo bo) {
        return toAjax(chatRobConfigService.insertByBo(bo));
    }

    /**
     * 修改聊天机器人配置
     */
    @SaCheckPermission("system:robConfig:edit")
    @Log(title = "聊天机器人配置", businessType = BusinessType.UPDATE)
    @RepeatSubmit()
    @PutMapping()
    public R<Void> edit(@Validated(EditGroup.class) @RequestBody ChatRobConfigBo bo) {
        return toAjax(chatRobConfigService.updateByBo(bo));
    }

    /**
     * 删除聊天机器人配置
     *
     * @param ids 主键串
     */
    @SaCheckPermission("system:robConfig:remove")
    @Log(title = "聊天机器人配置", businessType = BusinessType.DELETE)
    @DeleteMapping("/{ids}")
    public R<Void> remove(@NotEmpty(message = "主键不能为空")
                          @PathVariable Long[] ids) {
        return toAjax(chatRobConfigService.deleteWithValidByIds(List.of(ids), true));
    }
}
