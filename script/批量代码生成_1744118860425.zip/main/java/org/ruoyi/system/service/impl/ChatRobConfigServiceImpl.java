package org.ruoyi.system.service.impl;

import org.ruoyi.common.core.utils.MapstructUtils;
import org.ruoyi.common.mybatis.core.page.TableDataInfo;
import org.ruoyi.common.mybatis.core.page.PageQuery;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.ruoyi.system.domain.bo.ChatRobConfigBo;
import org.ruoyi.system.domain.vo.ChatRobConfigVo;
import org.ruoyi.system.domain.ChatRobConfig;
import org.ruoyi.system.mapper.ChatRobConfigMapper;
import org.ruoyi.system.service.IChatRobConfigService;

import java.util.List;
import java.util.Map;
import java.util.Collection;

/**
 * 聊天机器人配置Service业务层处理
 *
 * @author ageerle
 * @date 2025-04-08
 */
@RequiredArgsConstructor
@Service
public class ChatRobConfigServiceImpl implements IChatRobConfigService {

    private final ChatRobConfigMapper baseMapper;

    /**
     * 查询聊天机器人配置
     */
    @Override
    public ChatRobConfigVo queryById(Long id){
        return baseMapper.selectVoById(id);
    }

    /**
     * 查询聊天机器人配置列表
     */
    @Override
    public TableDataInfo<ChatRobConfigVo> queryPageList(ChatRobConfigBo bo, PageQuery pageQuery) {
        LambdaQueryWrapper<ChatRobConfig> lqw = buildQueryWrapper(bo);
        Page<ChatRobConfigVo> result = baseMapper.selectVoPage(pageQuery.build(), lqw);
        return TableDataInfo.build(result);
    }

    /**
     * 查询聊天机器人配置列表
     */
    @Override
    public List<ChatRobConfigVo> queryList(ChatRobConfigBo bo) {
        LambdaQueryWrapper<ChatRobConfig> lqw = buildQueryWrapper(bo);
        return baseMapper.selectVoList(lqw);
    }

    private LambdaQueryWrapper<ChatRobConfig> buildQueryWrapper(ChatRobConfigBo bo) {
        Map<String, Object> params = bo.getParams();
        LambdaQueryWrapper<ChatRobConfig> lqw = Wrappers.lambdaQuery();
        lqw.eq(bo.getUserId() != null, ChatRobConfig::getUserId, bo.getUserId());
        lqw.like(StringUtils.isNotBlank(bo.getBotName()), ChatRobConfig::getBotName, bo.getBotName());
        lqw.eq(StringUtils.isNotBlank(bo.getUniqueKey()), ChatRobConfig::getUniqueKey, bo.getUniqueKey());
        lqw.eq(StringUtils.isNotBlank(bo.getDefaultFriend()), ChatRobConfig::getDefaultFriend, bo.getDefaultFriend());
        lqw.eq(StringUtils.isNotBlank(bo.getDefaultGroup()), ChatRobConfig::getDefaultGroup, bo.getDefaultGroup());
        lqw.eq(StringUtils.isNotBlank(bo.getEnable()), ChatRobConfig::getEnable, bo.getEnable());
        return lqw;
    }

    /**
     * 新增聊天机器人配置
     */
    @Override
    public Boolean insertByBo(ChatRobConfigBo bo) {
        ChatRobConfig add = MapstructUtils.convert(bo, ChatRobConfig.class);
        validEntityBeforeSave(add);
        boolean flag = baseMapper.insert(add) > 0;
        if (flag) {
            bo.setId(add.getId());
        }
        return flag;
    }

    /**
     * 修改聊天机器人配置
     */
    @Override
    public Boolean updateByBo(ChatRobConfigBo bo) {
        ChatRobConfig update = MapstructUtils.convert(bo, ChatRobConfig.class);
        validEntityBeforeSave(update);
        return baseMapper.updateById(update) > 0;
    }

    /**
     * 保存前的数据校验
     */
    private void validEntityBeforeSave(ChatRobConfig entity){
        //TODO 做一些数据校验,如唯一约束
    }

    /**
     * 批量删除聊天机器人配置
     */
    @Override
    public Boolean deleteWithValidByIds(Collection<Long> ids, Boolean isValid) {
        if(isValid){
            //TODO 做一些业务上的校验,判断是否需要校验
        }
        return baseMapper.deleteBatchIds(ids) > 0;
    }
}
