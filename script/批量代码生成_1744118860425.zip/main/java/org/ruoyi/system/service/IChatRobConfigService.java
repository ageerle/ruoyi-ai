package org.ruoyi.system.service;

import org.ruoyi.system.domain.ChatRobConfig;
import org.ruoyi.system.domain.vo.ChatRobConfigVo;
import org.ruoyi.system.domain.bo.ChatRobConfigBo;
import org.ruoyi.common.mybatis.core.page.TableDataInfo;
import org.ruoyi.common.mybatis.core.page.PageQuery;

import java.util.Collection;
import java.util.List;

/**
 * 聊天机器人配置Service接口
 *
 * @author ageerle
 * @date 2025-04-08
 */
public interface IChatRobConfigService {

    /**
     * 查询聊天机器人配置
     */
    ChatRobConfigVo queryById(Long id);

    /**
     * 查询聊天机器人配置列表
     */
    TableDataInfo<ChatRobConfigVo> queryPageList(ChatRobConfigBo bo, PageQuery pageQuery);

    /**
     * 查询聊天机器人配置列表
     */
    List<ChatRobConfigVo> queryList(ChatRobConfigBo bo);

    /**
     * 新增聊天机器人配置
     */
    Boolean insertByBo(ChatRobConfigBo bo);

    /**
     * 修改聊天机器人配置
     */
    Boolean updateByBo(ChatRobConfigBo bo);

    /**
     * 校验并批量删除聊天机器人配置信息
     */
    Boolean deleteWithValidByIds(Collection<Long> ids, Boolean isValid);
}
