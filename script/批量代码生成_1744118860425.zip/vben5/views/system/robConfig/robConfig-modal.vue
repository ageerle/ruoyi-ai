<!--
使用antd原生Form生成 详细用法参考ant-design-vue Form组件文档
vscode默认配置文件会自动格式化/移除未使用依赖
-->
<script setup lang="ts">
import type { RuleObject } from 'ant-design-vue/es/form';
import { computed, ref } from 'vue';

import { Input, Textarea, Select, RadioGroup, CheckboxGroup, DatePicker, Form, FormItem } from 'ant-design-vue';
import { ImageUpload, FileUpload } from '#/components/upload';
import { Tinymce } from '#/components/tinymce';
import { getPopupContainer } from '@vben/utils';
import { pick } from 'lodash-es';


import { useVbenModal } from '@vben/common-ui';
import { $t } from '@vben/locales';
import { cloneDeep } from '@vben/utils';

import { useVbenForm } from '#/adapter/form';
import { robConfigAdd, robConfigInfo, robConfigUpdate } from '#/api/system/robConfig';
import type { RobConfigForm } from '#/api/system/robConfig/model';

const emit = defineEmits<{ reload: [] }>();

const isUpdate = ref(false);
const title = computed(() => {
  return isUpdate.value ? $t('pages.common.edit') : $t('pages.common.add');
});

/**
 * 定义默认值 用于reset
 */
const defaultValues: Partial<RobConfigForm> = {
  id: undefined,
  userId: undefined,
  botName: undefined,
  uniqueKey: undefined,
  defaultFriend: undefined,
  defaultGroup: undefined,
  enable: undefined,
  remark: undefined
}

/**
 * 表单数据ref
 */
const formData = ref(defaultValues);

type AntdFormRules<T> = Partial<Record<keyof T, RuleObject[]>> & {
  [key: string]: RuleObject[];
};
/**
 * 表单校验规则
 */
const formRules = ref<AntdFormRules<RobConfigForm>>({
    userId: [
      { required: true, message: "所属用户不能为空" }
    ],
    botName: [
      { required: true, message: "机器人名称不能为空" }
    ],
    uniqueKey: [
      { required: true, message: "机器唯一码不能为空" }
    ],
    defaultFriend: [
      { required: true, message: "默认好友回复开关不能为空" }
    ],
    defaultGroup: [
      { required: true, message: "默认群回复开关不能为空" }
    ],
    enable: [
      { required: true, message: "机器人状态  0正常 1启用不能为空" }
    ],
    remark: [
      { required: true, message: "备注不能为空" }
    ]
});

/**
 * useForm解构出表单方法
 */
const { validate, validateInfos, resetFields } = Form.useForm(
  formData,
  formRules,
);

const [BasicModal, modalApi] = useVbenModal({
  class: 'w-[550px]',
  fullscreenButton: false,
  closeOnClickModal: false,
  onClosed: handleCancel,
  onConfirm: handleConfirm,
  onOpenChange: async (isOpen) => {
    if (!isOpen) {
      return null;
    }
    modalApi.modalLoading(true);

    const { id } = modalApi.getData() as { id?: number | string };
    isUpdate.value = !!id;

    if (isUpdate.value && id) {
      const record = await robConfigInfo(id);
      // 只赋值存在的字段
      const filterRecord = pick(record, Object.keys(defaultValues));
      formData.value = filterRecord;
    }

    modalApi.modalLoading(false);
  },
});

async function handleConfirm() {
  try {
    modalApi.modalLoading(true);
    await validate();
    // 可能会做数据处理 使用cloneDeep深拷贝
    const data = cloneDeep(formData.value);
    await (isUpdate.value ? robConfigUpdate(data) : robConfigAdd(data));
    emit('reload');
    await handleCancel();
  } catch (error) {
    console.error(error);
  } finally {
    modalApi.modalLoading(false);
  }
}

async function handleCancel() {
  modalApi.close();
  formData.value = defaultValues;
  resetFields();
}
</script>

<template>
  <BasicModal :title="title">
    <Form :label-col="{ span: 4 }">
      <FormItem label="所属用户" v-bind="validateInfos.userId">
        <Input v-model:value="formData.userId" :placeholder="$t('ui.formRules.required')" />
      </FormItem>
      <FormItem label="机器人名称" v-bind="validateInfos.botName">
        <Input v-model:value="formData.botName" :placeholder="$t('ui.formRules.required')" />
      </FormItem>
      <FormItem label="机器唯一码" v-bind="validateInfos.uniqueKey">
        <Input v-model:value="formData.uniqueKey" :placeholder="$t('ui.formRules.required')" />
      </FormItem>
      <FormItem label="默认好友回复开关" v-bind="validateInfos.defaultFriend">
        <Input v-model:value="formData.defaultFriend" :placeholder="$t('ui.formRules.required')" />
      </FormItem>
      <FormItem label="默认群回复开关" v-bind="validateInfos.defaultGroup">
        <Input v-model:value="formData.defaultGroup" :placeholder="$t('ui.formRules.required')" />
      </FormItem>
      <FormItem label="机器人状态  0正常 1启用" v-bind="validateInfos.enable">
        <Input v-model:value="formData.enable" :placeholder="$t('ui.formRules.required')" />
      </FormItem>
      <FormItem label="备注" v-bind="validateInfos.remark">
        <Textarea 
          v-model:value="formData.remark" 
          :placeholder="$t('ui.formRules.required')" 
          :rows="4" 
        />
      </FormItem>
    </Form>
  </BasicModal>
</template>

