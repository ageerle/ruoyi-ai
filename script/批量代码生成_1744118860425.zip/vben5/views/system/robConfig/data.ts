import type { FormSchemaGetter } from '#/adapter/form';
import type { VxeGridProps } from '#/adapter/vxe-table';


export const querySchema: FormSchemaGetter = () => [
  {
    component: 'Input',
    fieldName: 'userId',
    label: '所属用户',
  },
  {
    component: 'Input',
    fieldName: 'botName',
    label: '机器人名称',
  },
  {
    component: 'Input',
    fieldName: 'uniqueKey',
    label: '机器唯一码',
  },
  {
    component: 'Input',
    fieldName: 'defaultFriend',
    label: '默认好友回复开关',
  },
  {
    component: 'Input',
    fieldName: 'defaultGroup',
    label: '默认群回复开关',
  },
  {
    component: 'Input',
    fieldName: 'enable',
    label: '机器人状态  0正常 1启用',
  },
];

// 需要使用i18n注意这里要改成getter形式 否则切换语言不会刷新
// export const columns: () => VxeGridProps['columns'] = () => [
export const columns: VxeGridProps['columns'] = [
  { type: 'checkbox', width: 60 },
  {
    title: '主键',
    field: 'id',
  },
  {
    title: '所属用户',
    field: 'userId',
  },
  {
    title: '机器人名称',
    field: 'botName',
  },
  {
    title: '机器唯一码',
    field: 'uniqueKey',
  },
  {
    title: '默认好友回复开关',
    field: 'defaultFriend',
  },
  {
    title: '默认群回复开关',
    field: 'defaultGroup',
  },
  {
    title: '机器人状态  0正常 1启用',
    field: 'enable',
  },
  {
    title: '备注',
    field: 'remark',
  },
  {
    field: 'action',
    fixed: 'right',
    slots: { default: 'action' },
    title: '操作',
    width: 180,
  },
];

