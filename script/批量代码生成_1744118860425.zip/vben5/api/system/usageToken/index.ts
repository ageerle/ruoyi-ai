import type { UsageTokenVO, UsageTokenForm, UsageTokenQuery } from './model';

import type { ID, IDS } from '#/api/common';
import type { PageResult } from '#/api/common';

import { commonExport } from '#/api/helper';
import { requestClient } from '#/api/request';

/**
* 查询用户token使用详情列表
* @param params
* @returns 用户token使用详情列表
*/
export function usageTokenList(params?: UsageTokenQuery) {
  return requestClient.get<PageResult<UsageTokenVO>>('/system/usageToken/list', { params });
}

/**
 * 导出用户token使用详情列表
 * @param params
 * @returns 用户token使用详情列表
 */
export function usageTokenExport(params?: UsageTokenQuery) {
  return commonExport('/system/usageToken/export', params ?? {});
}

/**
 * 查询用户token使用详情详情
 * @param id id
 * @returns 用户token使用详情详情
 */
export function usageTokenInfo(id: ID) {
  return requestClient.get<UsageTokenVO>(`/system/usageToken/${id}`);
}

/**
 * 新增用户token使用详情
 * @param data
 * @returns void
 */
export function usageTokenAdd(data: UsageTokenForm) {
  return requestClient.postWithMsg<void>('/system/usageToken', data);
}

/**
 * 更新用户token使用详情
 * @param data
 * @returns void
 */
export function usageTokenUpdate(data: UsageTokenForm) {
  return requestClient.putWithMsg<void>('/system/usageToken', data);
}

/**
 * 删除用户token使用详情
 * @param id id
 * @returns void
 */
export function usageTokenRemove(id: ID | IDS) {
  return requestClient.deleteWithMsg<void>(`/system/usageToken/${id}`);
}
