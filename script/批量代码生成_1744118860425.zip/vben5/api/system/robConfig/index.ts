import type { RobConfigVO, RobConfigForm, RobConfigQuery } from './model';

import type { ID, IDS } from '#/api/common';
import type { PageResult } from '#/api/common';

import { commonExport } from '#/api/helper';
import { requestClient } from '#/api/request';

/**
* 查询聊天机器人配置列表
* @param params
* @returns 聊天机器人配置列表
*/
export function robConfigList(params?: RobConfigQuery) {
  return requestClient.get<PageResult<RobConfigVO>>('/system/robConfig/list', { params });
}

/**
 * 导出聊天机器人配置列表
 * @param params
 * @returns 聊天机器人配置列表
 */
export function robConfigExport(params?: RobConfigQuery) {
  return commonExport('/system/robConfig/export', params ?? {});
}

/**
 * 查询聊天机器人配置详情
 * @param id id
 * @returns 聊天机器人配置详情
 */
export function robConfigInfo(id: ID) {
  return requestClient.get<RobConfigVO>(`/system/robConfig/${id}`);
}

/**
 * 新增聊天机器人配置
 * @param data
 * @returns void
 */
export function robConfigAdd(data: RobConfigForm) {
  return requestClient.postWithMsg<void>('/system/robConfig', data);
}

/**
 * 更新聊天机器人配置
 * @param data
 * @returns void
 */
export function robConfigUpdate(data: RobConfigForm) {
  return requestClient.putWithMsg<void>('/system/robConfig', data);
}

/**
 * 删除聊天机器人配置
 * @param id id
 * @returns void
 */
export function robConfigRemove(id: ID | IDS) {
  return requestClient.deleteWithMsg<void>(`/system/robConfig/${id}`);
}
