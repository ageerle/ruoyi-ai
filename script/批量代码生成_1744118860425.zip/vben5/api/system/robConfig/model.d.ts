import type { PageQuery, BaseEntity } from '#/api/common';

export interface RobConfigVO {
  /**
   * 主键
   */
  id: string | number;

  /**
   * 所属用户
   */
  userId: string | number;

  /**
   * 机器人名称
   */
  botName: string;

  /**
   * 机器唯一码
   */
  uniqueKey: string;

  /**
   * 默认好友回复开关
   */
  defaultFriend: string;

  /**
   * 默认群回复开关
   */
  defaultGroup: string;

  /**
   * 机器人状态  0正常 1启用
   */
  enable: string;

  /**
   * 备注
   */
  remark: string;

}

export interface RobConfigForm extends BaseEntity {
  /**
   * 主键
   */
  id?: string | number;

  /**
   * 所属用户
   */
  userId?: string | number;

  /**
   * 机器人名称
   */
  botName?: string;

  /**
   * 机器唯一码
   */
  uniqueKey?: string;

  /**
   * 默认好友回复开关
   */
  defaultFriend?: string;

  /**
   * 默认群回复开关
   */
  defaultGroup?: string;

  /**
   * 机器人状态  0正常 1启用
   */
  enable?: string;

  /**
   * 备注
   */
  remark?: string;

}

export interface RobConfigQuery extends PageQuery {
  /**
   * 所属用户
   */
  userId?: string | number;

  /**
   * 机器人名称
   */
  botName?: string;

  /**
   * 机器唯一码
   */
  uniqueKey?: string;

  /**
   * 默认好友回复开关
   */
  defaultFriend?: string;

  /**
   * 默认群回复开关
   */
  defaultGroup?: string;

  /**
   * 机器人状态  0正常 1启用
   */
  enable?: string;

  /**
    * 日期范围参数
    */
  params?: any;
}
