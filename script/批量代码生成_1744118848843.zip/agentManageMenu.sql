-- 菜单 SQL
insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(1909598972644261890, '智能体管理', '3', '1', 'agentManage', 'system/agentManage/index', 1, 0, 'C', '0', '0', 'system:agentManage:list', '#', 103, 1, sysdate(), null, null, '智能体管理菜单');

-- 按钮 SQL
insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(1909598972644261891, '智能体管理查询', 1909598972644261890, '1',  '#', '', 1, 0, 'F', '0', '0', 'system:agentManage:query',        '#', 103, 1, sysdate(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(1909598972644261892, '智能体管理新增', 1909598972644261890, '2',  '#', '', 1, 0, 'F', '0', '0', 'system:agentManage:add',          '#', 103, 1, sysdate(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(1909598972644261893, '智能体管理修改', 1909598972644261890, '3',  '#', '', 1, 0, 'F', '0', '0', 'system:agentManage:edit',         '#', 103, 1, sysdate(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(1909598972644261894, '智能体管理删除', 1909598972644261890, '4',  '#', '', 1, 0, 'F', '0', '0', 'system:agentManage:remove',       '#', 103, 1, sysdate(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(1909598972644261895, '智能体管理导出', 1909598972644261890, '5',  '#', '', 1, 0, 'F', '0', '0', 'system:agentManage:export',       '#', 103, 1, sysdate(), null, null, '');
