-- 菜单 SQL
insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(1909598972057059330, '插件管理', '3', '1', 'plugin', 'system/plugin/index', 1, 0, 'C', '0', '0', 'system:plugin:list', '#', 103, 1, sysdate(), null, null, '插件管理菜单');

-- 按钮 SQL
insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(1909598972057059331, '插件管理查询', 1909598972057059330, '1',  '#', '', 1, 0, 'F', '0', '0', 'system:plugin:query',        '#', 103, 1, sysdate(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(1909598972057059332, '插件管理新增', 1909598972057059330, '2',  '#', '', 1, 0, 'F', '0', '0', 'system:plugin:add',          '#', 103, 1, sysdate(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(1909598972057059333, '插件管理修改', 1909598972057059330, '3',  '#', '', 1, 0, 'F', '0', '0', 'system:plugin:edit',         '#', 103, 1, sysdate(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(1909598972057059334, '插件管理删除', 1909598972057059330, '4',  '#', '', 1, 0, 'F', '0', '0', 'system:plugin:remove',       '#', 103, 1, sysdate(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(1909598972057059335, '插件管理导出', 1909598972057059330, '5',  '#', '', 1, 0, 'F', '0', '0', 'system:plugin:export',       '#', 103, 1, sysdate(), null, null, '');
