<!--
使用antd原生Form生成 详细用法参考ant-design-vue Form组件文档
vscode默认配置文件会自动格式化/移除未使用依赖
-->
<script setup lang="ts">
import type { RuleObject } from 'ant-design-vue/es/form';
import { computed, ref } from 'vue';

import { Input, Textarea, Select, RadioGroup, CheckboxGroup, DatePicker, Form, FormItem } from 'ant-design-vue';
import { ImageUpload, FileUpload } from '#/components/upload';
import { Tinymce } from '#/components/tinymce';
import { getPopupContainer } from '@vben/utils';
import { pick } from 'lodash-es';


import { useVbenModal } from '@vben/common-ui';
import { $t } from '@vben/locales';
import { cloneDeep } from '@vben/utils';

import { useVbenForm } from '#/adapter/form';
import { agentManageAdd, agentManageInfo, agentManageUpdate } from '#/api/system/agentManage';
import type { AgentManageForm } from '#/api/system/agentManage/model';

const emit = defineEmits<{ reload: [] }>();

const isUpdate = ref(false);
const title = computed(() => {
  return isUpdate.value ? $t('pages.common.edit') : $t('pages.common.add');
});

/**
 * 定义默认值 用于reset
 */
const defaultValues: Partial<AgentManageForm> = {
  id: undefined,
  appName: undefined,
  appType: undefined,
  appIcon: undefined,
  appDescription: undefined,
  introduction: undefined,
  model: undefined,
  conversationModel: undefined,
  applicationSettings: undefined,
  pluginId: undefined,
  knowledgeId: undefined,
  remark: undefined
}

/**
 * 表单数据ref
 */
const formData = ref(defaultValues);

type AntdFormRules<T> = Partial<Record<keyof T, RuleObject[]>> & {
  [key: string]: RuleObject[];
};
/**
 * 表单校验规则
 */
const formRules = ref<AntdFormRules<AgentManageForm>>({
    appName: [
      { required: true, message: "应用名称不能为空" }
    ],
    appType: [
      { required: true, message: "应用类型不能为空" }
    ],
    appIcon: [
      { required: true, message: "应用头像不能为空" }
    ],
    appDescription: [
      { required: true, message: "应用描述不能为空" }
    ],
    introduction: [
      { required: true, message: "开场介绍不能为空" }
    ],
    model: [
      { required: true, message: "模型不能为空" }
    ],
    conversationModel: [
      { required: true, message: "对话可选模型不能为空" }
    ],
    applicationSettings: [
      { required: true, message: "应用设定不能为空" }
    ],
    pluginId: [
      { required: true, message: "插件id不能为空" }
    ],
    knowledgeId: [
      { required: true, message: "知识库id不能为空" }
    ],
    remark: [
      { required: true, message: "备注不能为空" }
    ]
});

/**
 * useForm解构出表单方法
 */
const { validate, validateInfos, resetFields } = Form.useForm(
  formData,
  formRules,
);

const [BasicModal, modalApi] = useVbenModal({
  class: 'w-[550px]',
  fullscreenButton: false,
  closeOnClickModal: false,
  onClosed: handleCancel,
  onConfirm: handleConfirm,
  onOpenChange: async (isOpen) => {
    if (!isOpen) {
      return null;
    }
    modalApi.modalLoading(true);

    const { id } = modalApi.getData() as { id?: number | string };
    isUpdate.value = !!id;

    if (isUpdate.value && id) {
      const record = await agentManageInfo(id);
      // 只赋值存在的字段
      const filterRecord = pick(record, Object.keys(defaultValues));
      formData.value = filterRecord;
    }

    modalApi.modalLoading(false);
  },
});

async function handleConfirm() {
  try {
    modalApi.modalLoading(true);
    await validate();
    // 可能会做数据处理 使用cloneDeep深拷贝
    const data = cloneDeep(formData.value);
    await (isUpdate.value ? agentManageUpdate(data) : agentManageAdd(data));
    emit('reload');
    await handleCancel();
  } catch (error) {
    console.error(error);
  } finally {
    modalApi.modalLoading(false);
  }
}

async function handleCancel() {
  modalApi.close();
  formData.value = defaultValues;
  resetFields();
}
</script>

<template>
  <BasicModal :title="title">
    <Form :label-col="{ span: 4 }">
      <FormItem label="应用名称" v-bind="validateInfos.appName">
        <Input v-model:value="formData.appName" :placeholder="$t('ui.formRules.required')" />
      </FormItem>
      <FormItem label="应用类型" v-bind="validateInfos.appType">
        <Select
          v-model:value="formData.appType"
          :options="[]"
          :getPopupContainer="getPopupContainer"
          :placeholder="$t('ui.formRules.selectRequired')"
        />
      </FormItem>
      <FormItem label="应用头像" v-bind="validateInfos.appIcon">
        <Input v-model:value="formData.appIcon" :placeholder="$t('ui.formRules.required')" />
      </FormItem>
      <FormItem label="应用描述" v-bind="validateInfos.appDescription">
        <Textarea 
          v-model:value="formData.appDescription" 
          :placeholder="$t('ui.formRules.required')" 
          :rows="4" 
        />
      </FormItem>
      <FormItem label="开场介绍" v-bind="validateInfos.introduction">
        <Textarea 
          v-model:value="formData.introduction" 
          :placeholder="$t('ui.formRules.required')" 
          :rows="4" 
        />
      </FormItem>
      <FormItem label="模型" v-bind="validateInfos.model">
        <Input v-model:value="formData.model" :placeholder="$t('ui.formRules.required')" />
      </FormItem>
      <FormItem label="对话可选模型" v-bind="validateInfos.conversationModel">
        <Input v-model:value="formData.conversationModel" :placeholder="$t('ui.formRules.required')" />
      </FormItem>
      <FormItem label="应用设定" v-bind="validateInfos.applicationSettings">
        <Textarea 
          v-model:value="formData.applicationSettings" 
          :placeholder="$t('ui.formRules.required')" 
          :rows="4" 
        />
      </FormItem>
      <FormItem label="插件id" v-bind="validateInfos.pluginId">
        <Input v-model:value="formData.pluginId" :placeholder="$t('ui.formRules.required')" />
      </FormItem>
      <FormItem label="知识库id" v-bind="validateInfos.knowledgeId">
        <Input v-model:value="formData.knowledgeId" :placeholder="$t('ui.formRules.required')" />
      </FormItem>
      <FormItem label="备注" v-bind="validateInfos.remark">
        <Textarea 
          v-model:value="formData.remark" 
          :placeholder="$t('ui.formRules.required')" 
          :rows="4" 
        />
      </FormItem>
    </Form>
  </BasicModal>
</template>

