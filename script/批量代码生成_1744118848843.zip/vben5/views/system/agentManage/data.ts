import type { FormSchemaGetter } from '#/adapter/form';
import type { VxeGridProps } from '#/adapter/vxe-table';


export const querySchema: FormSchemaGetter = () => [
  {
    component: 'Input',
    fieldName: 'appName',
    label: '应用名称',
  },
  {
    component: 'Select',
    componentProps: {
    },
    fieldName: 'appType',
    label: '应用类型',
  },
  {
    component: 'Input',
    fieldName: 'appIcon',
    label: '应用头像',
  },
  {
    component: 'Textarea',
    fieldName: 'appDescription',
    label: '应用描述',
  },
  {
    component: 'Textarea',
    fieldName: 'introduction',
    label: '开场介绍',
  },
  {
    component: 'Input',
    fieldName: 'model',
    label: '模型',
  },
  {
    component: 'Input',
    fieldName: 'conversationModel',
    label: '对话可选模型',
  },
  {
    component: 'Textarea',
    fieldName: 'applicationSettings',
    label: '应用设定',
  },
  {
    component: 'Input',
    fieldName: 'pluginId',
    label: '插件id',
  },
  {
    component: 'Input',
    fieldName: 'knowledgeId',
    label: '知识库id',
  },
];

// 需要使用i18n注意这里要改成getter形式 否则切换语言不会刷新
// export const columns: () => VxeGridProps['columns'] = () => [
export const columns: VxeGridProps['columns'] = [
  { type: 'checkbox', width: 60 },
  {
    title: '主键id',
    field: 'id',
  },
  {
    title: '应用名称',
    field: 'appName',
  },
  {
    title: '应用类型',
    field: 'appType',
  },
  {
    title: '应用头像',
    field: 'appIcon',
  },
  {
    title: '应用描述',
    field: 'appDescription',
  },
  {
    title: '开场介绍',
    field: 'introduction',
  },
  {
    title: '模型',
    field: 'model',
  },
  {
    title: '对话可选模型',
    field: 'conversationModel',
  },
  {
    title: '应用设定',
    field: 'applicationSettings',
  },
  {
    title: '插件id',
    field: 'pluginId',
  },
  {
    title: '知识库id',
    field: 'knowledgeId',
  },
  {
    title: '备注',
    field: 'remark',
  },
  {
    field: 'action',
    fixed: 'right',
    slots: { default: 'action' },
    title: '操作',
    width: 180,
  },
];

