import type { FormSchemaGetter } from '#/adapter/form';
import type { VxeGridProps } from '#/adapter/vxe-table';


export const querySchema: FormSchemaGetter = () => [
  {
    component: 'Input',
    fieldName: 'gid',
    label: 'gpts应用id',
  },
  {
    component: 'Input',
    fieldName: 'name',
    label: 'gpts应用名称',
  },
  {
    component: 'Input',
    fieldName: 'logo',
    label: 'gpts图标',
  },
  {
    component: 'Input',
    fieldName: 'info',
    label: 'gpts描述',
  },
  {
    component: 'Input',
    fieldName: 'authorId',
    label: '作者id',
  },
  {
    component: 'Input',
    fieldName: 'authorName',
    label: '作者名称',
  },
  {
    component: 'Input',
    fieldName: 'useCnt',
    label: '点赞',
  },
  {
    component: 'Input',
    fieldName: 'bad',
    label: '差评',
  },
  {
    component: 'Select',
    componentProps: {
    },
    fieldName: 'type',
    label: '类型',
  },
  {
    component: 'Input',
    fieldName: 'updateIp',
    label: '更新IP',
  },
];

// 需要使用i18n注意这里要改成getter形式 否则切换语言不会刷新
// export const columns: () => VxeGridProps['columns'] = () => [
export const columns: VxeGridProps['columns'] = [
  { type: 'checkbox', width: 60 },
  {
    title: 'id',
    field: 'id',
  },
  {
    title: 'gpts应用id',
    field: 'gid',
  },
  {
    title: 'gpts应用名称',
    field: 'name',
  },
  {
    title: 'gpts图标',
    field: 'logo',
  },
  {
    title: 'gpts描述',
    field: 'info',
  },
  {
    title: '作者id',
    field: 'authorId',
  },
  {
    title: '作者名称',
    field: 'authorName',
  },
  {
    title: '点赞',
    field: 'useCnt',
  },
  {
    title: '差评',
    field: 'bad',
  },
  {
    title: '类型',
    field: 'type',
  },
  {
    title: '备注',
    field: 'remark',
  },
  {
    title: '更新IP',
    field: 'updateIp',
  },
  {
    field: 'action',
    fixed: 'right',
    slots: { default: 'action' },
    title: '操作',
    width: 180,
  },
];

