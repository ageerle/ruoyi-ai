import type { FormSchemaGetter } from '#/adapter/form';
import type { VxeGridProps } from '#/adapter/vxe-table';


export const querySchema: FormSchemaGetter = () => [
  {
    component: 'Input',
    fieldName: 'category',
    label: '模型分类',
  },
  {
    component: 'Input',
    fieldName: 'modelName',
    label: '模型名称',
  },
  {
    component: 'Input',
    fieldName: 'modelDescribe',
    label: '模型描述',
  },
  {
    component: 'Input',
    fieldName: 'modelPrice',
    label: '模型价格',
  },
  {
    component: 'Select',
    componentProps: {
    },
    fieldName: 'modelType',
    label: '计费类型',
  },
  {
    component: 'Input',
    fieldName: 'modelShow',
    label: '是否显示',
  },
  {
    component: 'Input',
    fieldName: 'systemPrompt',
    label: '系统提示词',
  },
  {
    component: 'Input',
    fieldName: 'apiHost',
    label: '请求地址',
  },
  {
    component: 'Input',
    fieldName: 'apiKey',
    label: '密钥',
  },
];

// 需要使用i18n注意这里要改成getter形式 否则切换语言不会刷新
// export const columns: () => VxeGridProps['columns'] = () => [
export const columns: VxeGridProps['columns'] = [
  { type: 'checkbox', width: 60 },
  {
    title: '主键',
    field: 'id',
  },
  {
    title: '模型分类',
    field: 'category',
  },
  {
    title: '模型名称',
    field: 'modelName',
  },
  {
    title: '模型描述',
    field: 'modelDescribe',
  },
  {
    title: '模型价格',
    field: 'modelPrice',
  },
  {
    title: '计费类型',
    field: 'modelType',
  },
  {
    title: '是否显示',
    field: 'modelShow',
  },
  {
    title: '系统提示词',
    field: 'systemPrompt',
  },
  {
    title: '请求地址',
    field: 'apiHost',
  },
  {
    title: '密钥',
    field: 'apiKey',
  },
  {
    title: '备注',
    field: 'remark',
  },
  {
    field: 'action',
    fixed: 'right',
    slots: { default: 'action' },
    title: '操作',
    width: 180,
  },
];

