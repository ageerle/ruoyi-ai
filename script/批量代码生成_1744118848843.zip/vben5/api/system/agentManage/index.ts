import type { AgentManageVO, AgentManageForm, AgentManageQuery } from './model';

import type { ID, IDS } from '#/api/common';
import type { PageResult } from '#/api/common';

import { commonExport } from '#/api/helper';
import { requestClient } from '#/api/request';

/**
* 查询智能体管理列表
* @param params
* @returns 智能体管理列表
*/
export function agentManageList(params?: AgentManageQuery) {
  return requestClient.get<PageResult<AgentManageVO>>('/system/agentManage/list', { params });
}

/**
 * 导出智能体管理列表
 * @param params
 * @returns 智能体管理列表
 */
export function agentManageExport(params?: AgentManageQuery) {
  return commonExport('/system/agentManage/export', params ?? {});
}

/**
 * 查询智能体管理详情
 * @param id id
 * @returns 智能体管理详情
 */
export function agentManageInfo(id: ID) {
  return requestClient.get<AgentManageVO>(`/system/agentManage/${id}`);
}

/**
 * 新增智能体管理
 * @param data
 * @returns void
 */
export function agentManageAdd(data: AgentManageForm) {
  return requestClient.postWithMsg<void>('/system/agentManage', data);
}

/**
 * 更新智能体管理
 * @param data
 * @returns void
 */
export function agentManageUpdate(data: AgentManageForm) {
  return requestClient.putWithMsg<void>('/system/agentManage', data);
}

/**
 * 删除智能体管理
 * @param id id
 * @returns void
 */
export function agentManageRemove(id: ID | IDS) {
  return requestClient.deleteWithMsg<void>(`/system/agentManage/${id}`);
}
