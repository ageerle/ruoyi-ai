import type { AppStoreVO, AppStoreForm, AppStoreQuery } from './model';

import type { ID, IDS } from '#/api/common';
import type { PageResult } from '#/api/common';

import { commonExport } from '#/api/helper';
import { requestClient } from '#/api/request';

/**
* 查询应用商店列表
* @param params
* @returns 应用商店列表
*/
export function appStoreList(params?: AppStoreQuery) {
  return requestClient.get<PageResult<AppStoreVO>>('/system/appStore/list', { params });
}

/**
 * 导出应用商店列表
 * @param params
 * @returns 应用商店列表
 */
export function appStoreExport(params?: AppStoreQuery) {
  return commonExport('/system/appStore/export', params ?? {});
}

/**
 * 查询应用商店详情
 * @param id id
 * @returns 应用商店详情
 */
export function appStoreInfo(id: ID) {
  return requestClient.get<AppStoreVO>(`/system/appStore/${id}`);
}

/**
 * 新增应用商店
 * @param data
 * @returns void
 */
export function appStoreAdd(data: AppStoreForm) {
  return requestClient.postWithMsg<void>('/system/appStore', data);
}

/**
 * 更新应用商店
 * @param data
 * @returns void
 */
export function appStoreUpdate(data: AppStoreForm) {
  return requestClient.putWithMsg<void>('/system/appStore', data);
}

/**
 * 删除应用商店
 * @param id id
 * @returns void
 */
export function appStoreRemove(id: ID | IDS) {
  return requestClient.deleteWithMsg<void>(`/system/appStore/${id}`);
}
