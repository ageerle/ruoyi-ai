-- 菜单 SQL
insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(1909598973416013825, '应用商店', '3', '1', 'appStore', 'system/appStore/index', 1, 0, 'C', '0', '0', 'system:appStore:list', '#', 103, 1, sysdate(), null, null, '应用商店菜单');

-- 按钮 SQL
insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(1909598973416013826, '应用商店查询', 1909598973416013825, '1',  '#', '', 1, 0, 'F', '0', '0', 'system:appStore:query',        '#', 103, 1, sysdate(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(1909598973416013827, '应用商店新增', 1909598973416013825, '2',  '#', '', 1, 0, 'F', '0', '0', 'system:appStore:add',          '#', 103, 1, sysdate(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(1909598973416013828, '应用商店修改', 1909598973416013825, '3',  '#', '', 1, 0, 'F', '0', '0', 'system:appStore:edit',         '#', 103, 1, sysdate(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(1909598973416013829, '应用商店删除', 1909598973416013825, '4',  '#', '', 1, 0, 'F', '0', '0', 'system:appStore:remove',       '#', 103, 1, sysdate(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(1909598973416013830, '应用商店导出', 1909598973416013825, '5',  '#', '', 1, 0, 'F', '0', '0', 'system:appStore:export',       '#', 103, 1, sysdate(), null, null, '');
