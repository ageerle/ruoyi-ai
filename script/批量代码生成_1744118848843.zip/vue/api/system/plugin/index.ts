import request from '@/utils/request';
import {AxiosPromise} from 'axios';
import {PluginForm, PluginQuery, PluginVO} from '@/api/';

/**
 * 查询插件管理列表
 * @param query
 * @returns {*}
 */

export const listPlugin = (query?: PluginQuery): AxiosPromise<PluginVO[]> => {
  return request({
    url: '/system/plugin/list',
    method: 'get',
    params: query
  });
};

/**
 * 查询插件管理详细
 * @param id
 */
export const getPlugin = (id: string | number): AxiosPromise<PluginVO> => {
  return request({
    url: '/system/plugin/' + id,
    method: 'get'
  });
};

/**
 * 新增插件管理
 * @param data
 */
export const addPlugin = (data: PluginForm) => {
  return request({
    url: '/system/plugin',
    method: 'post',
    data: data
  });
};

/**
 * 修改插件管理
 * @param data
 */
export const updatePlugin = (data: PluginForm) => {
  return request({
    url: '/system/plugin',
    method: 'put',
    data: data
  });
};

/**
 * 删除插件管理
 * @param id
 */
export const delPlugin = (id: string | number | Array<string | number>) => {
  return request({
    url: '/system/plugin/' + id,
    method: 'delete'
  });
};
