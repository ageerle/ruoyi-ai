import request from '@/utils/request';
import {AxiosPromise} from 'axios';
import {VoucherForm, VoucherQuery, VoucherVO} from '@/api/';

/**
 * 查询用户兑换记录列表
 * @param query
 * @returns {*}
 */

export const listVoucher = (query?: VoucherQuery): AxiosPromise<VoucherVO[]> => {
  return request({
    url: '/system/voucher/list',
    method: 'get',
    params: query
  });
};

/**
 * 查询用户兑换记录详细
 * @param id
 */
export const getVoucher = (id: string | number): AxiosPromise<VoucherVO> => {
  return request({
    url: '/system/voucher/' + id,
    method: 'get'
  });
};

/**
 * 新增用户兑换记录
 * @param data
 */
export const addVoucher = (data: VoucherForm) => {
  return request({
    url: '/system/voucher',
    method: 'post',
    data: data
  });
};

/**
 * 修改用户兑换记录
 * @param data
 */
export const updateVoucher = (data: VoucherForm) => {
  return request({
    url: '/system/voucher',
    method: 'put',
    data: data
  });
};

/**
 * 删除用户兑换记录
 * @param id
 */
export const delVoucher = (id: string | number | Array<string | number>) => {
  return request({
    url: '/system/voucher/' + id,
    method: 'delete'
  });
};
