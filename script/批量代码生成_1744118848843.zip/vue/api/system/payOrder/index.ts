import request from '@/utils/request';
import {AxiosPromise} from 'axios';
import {PayOrderForm, PayOrderQuery, PayOrderVO} from '@/api/';

/**
 * 查询支付订单列表
 * @param query
 * @returns {*}
 */

export const listPayOrder = (query?: PayOrderQuery): AxiosPromise<PayOrderVO[]> => {
  return request({
    url: '/system/payOrder/list',
    method: 'get',
    params: query
  });
};

/**
 * 查询支付订单详细
 * @param id
 */
export const getPayOrder = (id: string | number): AxiosPromise<PayOrderVO> => {
  return request({
    url: '/system/payOrder/' + id,
    method: 'get'
  });
};

/**
 * 新增支付订单
 * @param data
 */
export const addPayOrder = (data: PayOrderForm) => {
  return request({
    url: '/system/payOrder',
    method: 'post',
    data: data
  });
};

/**
 * 修改支付订单
 * @param data
 */
export const updatePayOrder = (data: PayOrderForm) => {
  return request({
    url: '/system/payOrder',
    method: 'put',
    data: data
  });
};

/**
 * 删除支付订单
 * @param id
 */
export const delPayOrder = (id: string | number | Array<string | number>) => {
  return request({
    url: '/system/payOrder/' + id,
    method: 'delete'
  });
};
