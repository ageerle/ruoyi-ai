import request from '@/utils/request';
import {AxiosPromise} from 'axios';
import {GptsForm, GptsQuery, GptsVO} from '@/api/';

/**
 * 查询应用管理列表
 * @param query
 * @returns {*}
 */

export const listGpts = (query?: GptsQuery): AxiosPromise<GptsVO[]> => {
  return request({
    url: '/system/gpts/list',
    method: 'get',
    params: query
  });
};

/**
 * 查询应用管理详细
 * @param id
 */
export const getGpts = (id: string | number): AxiosPromise<GptsVO> => {
  return request({
    url: '/system/gpts/' + id,
    method: 'get'
  });
};

/**
 * 新增应用管理
 * @param data
 */
export const addGpts = (data: GptsForm) => {
  return request({
    url: '/system/gpts',
    method: 'post',
    data: data
  });
};

/**
 * 修改应用管理
 * @param data
 */
export const updateGpts = (data: GptsForm) => {
  return request({
    url: '/system/gpts',
    method: 'put',
    data: data
  });
};

/**
 * 删除应用管理
 * @param id
 */
export const delGpts = (id: string | number | Array<string | number>) => {
  return request({
    url: '/system/gpts/' + id,
    method: 'delete'
  });
};
