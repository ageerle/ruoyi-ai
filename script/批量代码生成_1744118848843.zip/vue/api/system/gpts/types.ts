export interface GptsVO {
  /**
   * id
   */
  id: string | number;

  /**
   * gpts应用id
   */
  gid: string | number;

  /**
   * gpts应用名称
   */
  name: string;

  /**
   * gpts图标
   */
  logo: string;

  /**
   * gpts描述
   */
  info: string;

  /**
   * 作者id
   */
  authorId: string | number;

  /**
   * 作者名称
   */
  authorName: string;

  /**
   * 点赞
   */
  useCnt: number;

  /**
   * 差评
   */
  bad: number;

  /**
   * 类型
   */
  type: string;

  /**
   * 备注
   */
  remark: string;

  /**
   * 更新IP
   */
  updateIp: string;

}

export interface GptsForm extends BaseEntity {
  /**
   * id
   */
  id?: string | number;

  /**
   * gpts应用id
   */
  gid?: string | number;

  /**
   * gpts应用名称
   */
  name?: string;

  /**
   * gpts图标
   */
  logo?: string;

  /**
   * gpts描述
   */
  info?: string;

  /**
   * 作者id
   */
  authorId?: string | number;

  /**
   * 作者名称
   */
  authorName?: string;

  /**
   * 点赞
   */
  useCnt?: number;

  /**
   * 差评
   */
  bad?: number;

  /**
   * 类型
   */
  type?: string;

  /**
   * 备注
   */
  remark?: string;

  /**
   * 更新IP
   */
  updateIp?: string;

}

export interface GptsQuery extends PageQuery {
  /**
   * gpts应用id
   */
  gid?: string | number;

  /**
   * gpts应用名称
   */
  name?: string;

  /**
   * gpts图标
   */
  logo?: string;

  /**
   * gpts描述
   */
  info?: string;

  /**
   * 作者id
   */
  authorId?: string | number;

  /**
   * 作者名称
   */
  authorName?: string;

  /**
   * 点赞
   */
  useCnt?: number;

  /**
   * 差评
   */
  bad?: number;

  /**
   * 类型
   */
  type?: string;

  /**
   * 更新IP
   */
  updateIp?: string;

}
