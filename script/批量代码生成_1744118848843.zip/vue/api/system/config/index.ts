import request from '@/utils/request';
import {AxiosPromise} from 'axios';
import {ConfigForm, ConfigQuery, ConfigVO} from '@/api/';

/**
 * 查询配置信息列表
 * @param query
 * @returns {*}
 */

export const listConfig = (query?: ConfigQuery): AxiosPromise<ConfigVO[]> => {
  return request({
    url: '/system/config/list',
    method: 'get',
    params: query
  });
};

/**
 * 查询配置信息详细
 * @param id
 */
export const getConfig = (id: string | number): AxiosPromise<ConfigVO> => {
  return request({
    url: '/system/config/' + id,
    method: 'get'
  });
};

/**
 * 新增配置信息
 * @param data
 */
export const addConfig = (data: ConfigForm) => {
  return request({
    url: '/system/config',
    method: 'post',
    data: data
  });
};

/**
 * 修改配置信息
 * @param data
 */
export const updateConfig = (data: ConfigForm) => {
  return request({
    url: '/system/config',
    method: 'put',
    data: data
  });
};

/**
 * 删除配置信息
 * @param id
 */
export const delConfig = (id: string | number | Array<string | number>) => {
  return request({
    url: '/system/config/' + id,
    method: 'delete'
  });
};
