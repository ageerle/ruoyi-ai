import request from '@/utils/request';
import {AxiosPromise} from 'axios';
import {AgentManageForm, AgentManageQuery, AgentManageVO} from '@/api/';

/**
 * 查询智能体管理列表
 * @param query
 * @returns {*}
 */

export const listAgentManage = (query?: AgentManageQuery): AxiosPromise<AgentManageVO[]> => {
  return request({
    url: '/system/agentManage/list',
    method: 'get',
    params: query
  });
};

/**
 * 查询智能体管理详细
 * @param id
 */
export const getAgentManage = (id: string | number): AxiosPromise<AgentManageVO> => {
  return request({
    url: '/system/agentManage/' + id,
    method: 'get'
  });
};

/**
 * 新增智能体管理
 * @param data
 */
export const addAgentManage = (data: AgentManageForm) => {
  return request({
    url: '/system/agentManage',
    method: 'post',
    data: data
  });
};

/**
 * 修改智能体管理
 * @param data
 */
export const updateAgentManage = (data: AgentManageForm) => {
  return request({
    url: '/system/agentManage',
    method: 'put',
    data: data
  });
};

/**
 * 删除智能体管理
 * @param id
 */
export const delAgentManage = (id: string | number | Array<string | number>) => {
  return request({
    url: '/system/agentManage/' + id,
    method: 'delete'
  });
};
