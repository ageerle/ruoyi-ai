export interface AgentManageVO {
  /**
   * 主键id
   */
  id: string | number;

  /**
   * 应用名称
   */
  appName: string;

  /**
   * 应用类型
   */
  appType: string;

  /**
   * 应用头像
   */
  appIcon: string;

  /**
   * 应用描述
   */
  appDescription: string;

  /**
   * 开场介绍
   */
  introduction: string;

  /**
   * 模型
   */
  model: string;

  /**
   * 对话可选模型
   */
  conversationModel: string;

  /**
   * 应用设定
   */
  applicationSettings: string;

  /**
   * 插件id
   */
  pluginId: string | number;

  /**
   * 知识库id
   */
  knowledgeId: string | number;

  /**
   * 备注
   */
  remark: string;

}

export interface AgentManageForm extends BaseEntity {
  /**
   * 主键id
   */
  id?: string | number;

  /**
   * 应用名称
   */
  appName?: string;

  /**
   * 应用类型
   */
  appType?: string;

  /**
   * 应用头像
   */
  appIcon?: string;

  /**
   * 应用描述
   */
  appDescription?: string;

  /**
   * 开场介绍
   */
  introduction?: string;

  /**
   * 模型
   */
  model?: string;

  /**
   * 对话可选模型
   */
  conversationModel?: string;

  /**
   * 应用设定
   */
  applicationSettings?: string;

  /**
   * 插件id
   */
  pluginId?: string | number;

  /**
   * 知识库id
   */
  knowledgeId?: string | number;

  /**
   * 备注
   */
  remark?: string;

}

export interface AgentManageQuery extends PageQuery {
  /**
   * 应用名称
   */
  appName?: string;

  /**
   * 应用类型
   */
  appType?: string;

  /**
   * 应用头像
   */
  appIcon?: string;

  /**
   * 应用描述
   */
  appDescription?: string;

  /**
   * 开场介绍
   */
  introduction?: string;

  /**
   * 模型
   */
  model?: string;

  /**
   * 对话可选模型
   */
  conversationModel?: string;

  /**
   * 应用设定
   */
  applicationSettings?: string;

  /**
   * 插件id
   */
  pluginId?: string | number;

  /**
   * 知识库id
   */
  knowledgeId?: string | number;

}
