export interface AppStoreVO {
  /**
   * id
   */
  id: string | number;

  /**
   * 名称
   */
  name: string;

  /**
   * 描述
   */
  description: string;

  /**
   * logo
   */
  avatar: string;

  /**
   * 地址
   */
  appUrl: string;

  /**
   * 备注
   */
  remark: string;

}

export interface AppStoreForm extends BaseEntity {
  /**
   * id
   */
  id?: string | number;

  /**
   * 名称
   */
  name?: string;

  /**
   * 描述
   */
  description?: string;

  /**
   * logo
   */
  avatar?: string;

  /**
   * 地址
   */
  appUrl?: string;

  /**
   * 备注
   */
  remark?: string;

}

export interface AppStoreQuery extends PageQuery {
  /**
   * 名称
   */
  name?: string;

  /**
   * 描述
   */
  description?: string;

  /**
   * logo
   */
  avatar?: string;

  /**
   * 地址
   */
  appUrl?: string;

}
