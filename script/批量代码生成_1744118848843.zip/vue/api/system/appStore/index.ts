import request from '@/utils/request';
import {AxiosPromise} from 'axios';
import {AppStoreForm, AppStoreQuery, AppStoreVO} from '@/api/';

/**
 * 查询应用商店列表
 * @param query
 * @returns {*}
 */

export const listAppStore = (query?: AppStoreQuery): AxiosPromise<AppStoreVO[]> => {
  return request({
    url: '/system/appStore/list',
    method: 'get',
    params: query
  });
};

/**
 * 查询应用商店详细
 * @param id
 */
export const getAppStore = (id: string | number): AxiosPromise<AppStoreVO> => {
  return request({
    url: '/system/appStore/' + id,
    method: 'get'
  });
};

/**
 * 新增应用商店
 * @param data
 */
export const addAppStore = (data: AppStoreForm) => {
  return request({
    url: '/system/appStore',
    method: 'post',
    data: data
  });
};

/**
 * 修改应用商店
 * @param data
 */
export const updateAppStore = (data: AppStoreForm) => {
  return request({
    url: '/system/appStore',
    method: 'put',
    data: data
  });
};

/**
 * 删除应用商店
 * @param id
 */
export const delAppStore = (id: string | number | Array<string | number>) => {
  return request({
    url: '/system/appStore/' + id,
    method: 'delete'
  });
};
