-- 菜单 SQL
insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(1909598970698104834, '用户兑换记录', '3', '1', 'voucher', 'system/voucher/index', 1, 0, 'C', '0', '0', 'system:voucher:list', '#', 103, 1, sysdate(), null, null, '用户兑换记录菜单');

-- 按钮 SQL
insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(1909598970698104835, '用户兑换记录查询', 1909598970698104834, '1',  '#', '', 1, 0, 'F', '0', '0', 'system:voucher:query',        '#', 103, 1, sysdate(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(1909598970698104836, '用户兑换记录新增', 1909598970698104834, '2',  '#', '', 1, 0, 'F', '0', '0', 'system:voucher:add',          '#', 103, 1, sysdate(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(1909598970698104837, '用户兑换记录修改', 1909598970698104834, '3',  '#', '', 1, 0, 'F', '0', '0', 'system:voucher:edit',         '#', 103, 1, sysdate(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(1909598970698104838, '用户兑换记录删除', 1909598970698104834, '4',  '#', '', 1, 0, 'F', '0', '0', 'system:voucher:remove',       '#', 103, 1, sysdate(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(1909598970698104839, '用户兑换记录导出', 1909598970698104834, '5',  '#', '', 1, 0, 'F', '0', '0', 'system:voucher:export',       '#', 103, 1, sysdate(), null, null, '');
