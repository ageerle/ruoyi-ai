-- 菜单 SQL
insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(1909598968743559170, '套餐管理', '3', '1', 'packagePlan', 'system/packagePlan/index', 1, 0, 'C', '0', '0', 'system:packagePlan:list', '#', 103, 1, sysdate(), null, null, '套餐管理菜单');

-- 按钮 SQL
insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(1909598968743559171, '套餐管理查询', 1909598968743559170, '1',  '#', '', 1, 0, 'F', '0', '0', 'system:packagePlan:query',        '#', 103, 1, sysdate(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(1909598968743559172, '套餐管理新增', 1909598968743559170, '2',  '#', '', 1, 0, 'F', '0', '0', 'system:packagePlan:add',          '#', 103, 1, sysdate(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(1909598968743559173, '套餐管理修改', 1909598968743559170, '3',  '#', '', 1, 0, 'F', '0', '0', 'system:packagePlan:edit',         '#', 103, 1, sysdate(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(1909598968743559174, '套餐管理删除', 1909598968743559170, '4',  '#', '', 1, 0, 'F', '0', '0', 'system:packagePlan:remove',       '#', 103, 1, sysdate(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(1909598968743559175, '套餐管理导出', 1909598968743559170, '5',  '#', '', 1, 0, 'F', '0', '0', 'system:packagePlan:export',       '#', 103, 1, sysdate(), null, null, '');
