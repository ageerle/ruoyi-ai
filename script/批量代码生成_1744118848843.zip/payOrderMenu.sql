-- 菜单 SQL
insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(1909598970047987713, '支付订单', '3', '1', 'payOrder', 'system/payOrder/index', 1, 0, 'C', '0', '0', 'system:payOrder:list', '#', 103, 1, sysdate(), null, null, '支付订单菜单');

-- 按钮 SQL
insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(1909598970047987714, '支付订单查询', 1909598970047987713, '1',  '#', '', 1, 0, 'F', '0', '0', 'system:payOrder:query',        '#', 103, 1, sysdate(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(1909598970047987715, '支付订单新增', 1909598970047987713, '2',  '#', '', 1, 0, 'F', '0', '0', 'system:payOrder:add',          '#', 103, 1, sysdate(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(1909598970047987716, '支付订单修改', 1909598970047987713, '3',  '#', '', 1, 0, 'F', '0', '0', 'system:payOrder:edit',         '#', 103, 1, sysdate(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(1909598970047987717, '支付订单删除', 1909598970047987713, '4',  '#', '', 1, 0, 'F', '0', '0', 'system:payOrder:remove',       '#', 103, 1, sysdate(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(1909598970047987718, '支付订单导出', 1909598970047987713, '5',  '#', '', 1, 0, 'F', '0', '0', 'system:payOrder:export',       '#', 103, 1, sysdate(), null, null, '');
