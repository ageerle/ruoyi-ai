-- 菜单 SQL
insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(1909598966919036929, '聊天模型', '3', '1', 'model', 'system/model/index', 1, 0, 'C', '0', '0', 'system:model:list', '#', 103, 1, sysdate(), null, null, '聊天模型菜单');

-- 按钮 SQL
insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(1909598966919036930, '聊天模型查询', 1909598966919036929, '1',  '#', '', 1, 0, 'F', '0', '0', 'system:model:query',        '#', 103, 1, sysdate(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(1909598966919036931, '聊天模型新增', 1909598966919036929, '2',  '#', '', 1, 0, 'F', '0', '0', 'system:model:add',          '#', 103, 1, sysdate(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(1909598966919036932, '聊天模型修改', 1909598966919036929, '3',  '#', '', 1, 0, 'F', '0', '0', 'system:model:edit',         '#', 103, 1, sysdate(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(1909598966919036933, '聊天模型删除', 1909598966919036929, '4',  '#', '', 1, 0, 'F', '0', '0', 'system:model:remove',       '#', 103, 1, sysdate(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(1909598966919036934, '聊天模型导出', 1909598966919036929, '5',  '#', '', 1, 0, 'F', '0', '0', 'system:model:export',       '#', 103, 1, sysdate(), null, null, '');
