package org.ruoyi.system.mapper;

import org.ruoyi.system.domain.ChatPackagePlan;
import org.ruoyi.system.domain.vo.ChatPackagePlanVo;
import org.ruoyi.common.mybatis.core.mapper.BaseMapperPlus;

/**
 * 套餐管理Mapper接口
 *
 * @author ageerle
 * @date 2025-04-08
 */
public interface ChatPackagePlanMapper extends BaseMapperPlus<ChatPackagePlan, ChatPackagePlanVo> {

}
