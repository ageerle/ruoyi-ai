package org.ruoyi.system.mapper;

import org.ruoyi.system.domain.ChatModel;
import org.ruoyi.system.domain.vo.ChatModelVo;
import org.ruoyi.common.mybatis.core.mapper.BaseMapperPlus;

/**
 * 聊天模型Mapper接口
 *
 * @author ageerle
 * @date 2025-04-08
 */
public interface ChatModelMapper extends BaseMapperPlus<ChatModel, ChatModelVo> {

}
