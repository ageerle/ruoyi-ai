package org.ruoyi.system.mapper;

import org.ruoyi.system.domain.ChatGpts;
import org.ruoyi.system.domain.vo.ChatGptsVo;
import org.ruoyi.common.mybatis.core.mapper.BaseMapperPlus;

/**
 * 应用管理Mapper接口
 *
 * @author ageerle
 * @date 2025-04-08
 */
public interface ChatGptsMapper extends BaseMapperPlus<ChatGpts, ChatGptsVo> {

}
