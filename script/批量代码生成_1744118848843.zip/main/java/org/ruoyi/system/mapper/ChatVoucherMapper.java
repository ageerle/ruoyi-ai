package org.ruoyi.system.mapper;

import org.ruoyi.system.domain.ChatVoucher;
import org.ruoyi.system.domain.vo.ChatVoucherVo;
import org.ruoyi.common.mybatis.core.mapper.BaseMapperPlus;

/**
 * 用户兑换记录Mapper接口
 *
 * @author ageerle
 * @date 2025-04-08
 */
public interface ChatVoucherMapper extends BaseMapperPlus<ChatVoucher, ChatVoucherVo> {

}
