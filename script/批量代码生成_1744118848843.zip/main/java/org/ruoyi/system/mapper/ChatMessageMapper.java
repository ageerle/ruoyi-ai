package org.ruoyi.system.mapper;

import org.ruoyi.system.domain.ChatMessage;
import org.ruoyi.system.domain.vo.ChatMessageVo;
import org.ruoyi.common.mybatis.core.mapper.BaseMapperPlus;

/**
 * 聊天消息Mapper接口
 *
 * @author ageerle
 * @date 2025-04-08
 */
public interface ChatMessageMapper extends BaseMapperPlus<ChatMessage, ChatMessageVo> {

}
