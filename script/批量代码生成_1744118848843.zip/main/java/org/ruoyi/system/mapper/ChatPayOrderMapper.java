package org.ruoyi.system.mapper;

import org.ruoyi.system.domain.ChatPayOrder;
import org.ruoyi.system.domain.vo.ChatPayOrderVo;
import org.ruoyi.common.mybatis.core.mapper.BaseMapperPlus;

/**
 * 支付订单Mapper接口
 *
 * @author ageerle
 * @date 2025-04-08
 */
public interface ChatPayOrderMapper extends BaseMapperPlus<ChatPayOrder, ChatPayOrderVo> {

}
