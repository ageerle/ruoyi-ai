package org.ruoyi.system.domain.vo;

import org.ruoyi.system.domain.ChatPlugin;
import com.alibaba.excel.annotation.ExcelIgnoreUnannotated;
import com.alibaba.excel.annotation.ExcelProperty;
import annotation.excel.common.org.ruoyi.ExcelDictFormat;
import convert.excel.common.org.ruoyi.ExcelDictConvert;
import io.github.linpeilie.annotations.AutoMapper;
import lombok.Data;

import java.io.Serial;
import java.io.Serializable;
import java.util.Date;



/**
 * 插件管理视图对象 chat_plugin
 *
 * @author ageerle
 * @date 2025-04-08
 */
@Data
@ExcelIgnoreUnannotated
@AutoMapper(target = ChatPlugin.class)
public class ChatPluginVo implements Serializable {

    @Serial
    private static final long serialVersionUID = 1L;

    /**
     * 主键
     */
    @ExcelProperty(value = "主键")
    private Long id;

    /**
     * 插件名称
     */
    @ExcelProperty(value = "插件名称")
    private String name;

    /**
     * 插件编码
     */
    @ExcelProperty(value = "插件编码")
    private String code;

    /**
     * 备注
     */
    @ExcelProperty(value = "备注")
    private String remark;


}
